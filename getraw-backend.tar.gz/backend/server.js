// Get Raw Mixtapes — shared backend (Node + Express).
//
// This is what makes the site real: artists upload once, everyone can
// listen, and a user can log in on any phone or computer and see their
// own profile, tapes and drafts.
//
//   * Auth: @handle + password (scrypt-hashed, lib/auth.js), token
//     sessions stored server-side — the token works from any device.
//   * Tapes: drafts, Publish Now, Schedule a Premiere, live feed,
//     search + genre filter, Featured, Artist of the Week, Rankings
//     (Global / Local / Most Plays / Most Downloads / genre) and
//     Year-End stats. Plays and downloads are counted site-wide and
//     kept SEPARATE everywhere, never mixed.
//     Edit: PATCH /api/tapes/:id (owner only) updates any uploaded
//     field — title, artist, DJ, genre, city, description, $cashtag,
//     cover art, and each track's title — and can remove tracks.
//     Delete: DELETE /api/tapes/:id (owner only) and DELETE
//     /api/auth/me (whole account + all its tapes) remove the record,
//     the files on disk, and the tape from saved downloads.
//   * Email (optional): a user may give an email + tick "send me
//     promotions" at sign-up, on upload, or in their profile. It is
//     private — never in any public response — and Kris can list the
//     opted-in addresses via GET /api/admin/promo-emails (admin token).
//   * Profiles: the owner can edit name, city, bio and photo, and
//     change their password (current password required) — all from
//     their profile page. Photos live under uploads/avatars/<handle>/
//     and are served at /api/media/avatars/<handle>.
//   * Files: cover art + audio tracks are stored on this server's disk
//     (uploads/<tapeId>/), streamed with HTTP Range support so the
//     <audio> player can seek, and downloadable via DownloadManager.
//   * Data: plain JSON files in data/ (users.json, tapes.json,
//     sessions.json) — same durable pattern as the Hoopty backend.
//     No paid database, no third-party service.
//
// Separation from Hoopty (Kris, Nov 19, 2026): this service is
// COMPLETELY separate — its own directory (/opt/getraw), its own data
// (/opt/getraw/data), its own uploads (/opt/getraw/uploads), its own
// systemd unit (getraw), its own port (3001 — Hoopty is 3000) and its
// own address (https://api.getrawmixtapes.com — Hoopty is
// api.hoopty.rent). Nothing here reads or writes /opt/hoopty.
//
// RUN (local / deploy): npm install && npm start
//   PORT           default 3001
//   DATA_DIR       default ./data
//   UPLOADS_DIR    default ./uploads
//   FRONTEND_URL   default https://getrawmixtapes.com (CORS origin)
//   ADMIN_TOKEN    secret for the Featured-slot endpoint (set at deploy;
//                  if unset, that endpoint stays disabled)
//   SESSION_DAYS   default 30
"use strict";

const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const multer = require("multer");
const { ZipArchive } = require("archiver");
const { Store } = require("./lib/store");
const { hashPassword, verifyPassword, newToken, sessionExpiry, publicUser, privateUser, normEmail, validEmail } = require("./lib/auth");

const PORT = Number(process.env.PORT || 3001);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const UPLOADS_DIR = process.env.UPLOADS_DIR || path.join(__dirname, "uploads");
const FRONTEND_URL = (process.env.FRONTEND_URL || "https://getrawmixtapes.com").replace(/\/$/, "");
const GENRES = ["Hip-Hop", "Rap", "Trap", "Drill", "Boom Bap", "R&B", "Afrobeats", "Dancehall", "Grime", "Underground", "Other"];

const AUDIO_EXTS = { ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".wav": "audio/wav", ".flac": "audio/flac", ".ogg": "audio/ogg", ".aac": "audio/aac" };
const IMAGE_EXTS = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif" };
const MAX_TRACKS = 20;
const MAX_TRACK_BYTES = 150 * 1024 * 1024; // 150 MB per track
const MAX_COVER_BYTES = 10 * 1024 * 1024;  // 10 MB cover art

function createApp(opts) {
  const store = new Store((opts && opts.dataDir) || DATA_DIR);
  const uploadsDir = (opts && opts.uploadsDir) || UPLOADS_DIR;
  // Admin token: from the server .env in production; tests may pass
  // opts.adminToken so the promo-emails endpoint can be exercised.
  const ADMIN_TOKEN = (opts && opts.adminToken) || process.env.ADMIN_TOKEN || "";
  fs.mkdirSync(uploadsDir, { recursive: true });
  const app = express();
  app.disable("x-powered-by");
  // Behind nginx/Caddy (TLS ends at the proxy): trust X-Forwarded-Proto
  // so media URLs we build are https://, not http://.
  app.set("trust proxy", 1);
  app.use(express.json({ limit: "1mb" }));

  // CORS: the static site on getrawmixtapes.com (and the app, which loads
  // that site) is the only browser origin. curl / server-to-server calls
  // have no Origin and are allowed through.
  const ALLOWED_ORIGINS = new Set([FRONTEND_URL, "https://www.getrawmixtapes.com", "http://localhost:3000", "http://127.0.0.1:3000"]);
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && ALLOWED_ORIGINS.has(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
    } else if (origin && /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
    }
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
    if (req.method === "OPTIONS") return res.sendStatus(204);
    next();
  });

  // ---- tiny in-memory rate limits (per IP, per minute) -----------------
  const buckets = new Map();
  function rateLimit(max, windowMs) {
    return (req, res, next) => {
      const key = (req.ip || "x") + ":" + req.path;
      const now = Date.now();
      const b = buckets.get(key) || { count: 0, start: now };
      if (now - b.start > windowMs) { b.count = 0; b.start = now; }
      b.count += 1;
      buckets.set(key, b);
      if (b.count > max) return res.status(429).json({ ok: false, error: "Too many requests — slow down and try again." });
      next();
    };
  }

  // ---- helpers ----------------------------------------------------------
  function normHandle(h) {
    h = String(h || "").trim().toLowerCase();
    if (h && h.charAt(0) !== "@") h = "@" + h;
    return h.replace(/\s+/g, "");
  }
  function validHandle(h) {
    return /^@[a-z0-9._-]{2,32}$/.test(h || "");
  }
  // Promo opt-in arrives as a JSON boolean, or as a form string ("1" /
  // "true" from the upload form). Anything else counts as off.
  function parsePromoOptIn(v) {
    return v === true || v === 1 || v === "1" || v === "true";
  }
  function normCashtag(c) {
    c = String(c || "").trim().replace(/\s+/g, "");
    if (!c) return "";
    if (c.charAt(0) !== "$") c = "$" + c;
    return c.length > 1 ? c : "";
  }
  function tapeId() {
    return "t_" + Date.now().toString(36) + "_" + crypto.randomBytes(6).toString("hex");
  }
  function isLive(t) {
    return !t.draft && (!t.releaseAt || t.releaseAt <= Date.now());
  }
  function isScheduled(t) {
    return !t.draft && !!t.releaseAt && t.releaseAt > Date.now();
  }
  // Premieres whose time has come go live (persisted on next write; the
  // read path treats them as live immediately so nobody misses a drop).
  function sweepPremieres() {
    let changed = false;
    const now = Date.now();
    for (const t of store.tapes) {
      if (!t.draft && t.releaseAt && t.releaseAt <= now) {
        t.releaseAt = null;
        if (!t.publishedAt) t.publishedAt = now;
        changed = true;
      }
    }
    return changed;
  }
  function publicTape(t, req) {
    const base = (req ? req.protocol + "://" + req.get("host") : "");
    // The artist's profile picture, so the site can show it next to
    // their name on tape cards, the tape dialog, Artist of the Week
    // and the charts. Empty until the artist uploads a photo.
    const owner = store.users[t.handle];
    const artistAvatar = owner && owner.avatarFile && base ? base + "/api/media/avatars/" + t.handle.slice(1) : "";
    return {
      id: t.id, title: t.title, artist: t.artist, handle: t.handle,
      artistAvatar,
      dj: t.dj || "", genre: t.genre, city: t.city || "", desc: t.desc || "",
      cover: t.coverFile ? base + "/api/media/" + t.id + "/cover" : null,
      coverUrl: t.coverFile ? base + "/api/media/" + t.id + "/cover" : null,
      tracks: (t.tracks || []).map((tr, i) => ({
        idx: i, title: tr.title, fileName: tr.fileName,
        url: base + "/api/media/" + t.id + "/track/" + i,
        downloadUrl: base + "/api/media/" + t.id + "/track/" + i + "?download=1",
      })),
      releaseAt: t.releaseAt || null, draft: !!t.draft,
      featured: !!t.featured, plays: t.plays || 0, downloads: t.downloads || 0,
      // Fan reactions: counts only — voteBy (who voted) never leaves
      // the server, and comments travel on their own endpoint.
      up: (t.votes && t.votes.up) || 0, down: (t.votes && t.votes.down) || 0,
      commentCount: (t.comments || []).length,
      cashtag: normCashtag(t.cashtag || ""),
      createdAt: t.createdAt, publishedAt: t.publishedAt || null,
    };
  }
  function apiBase(req) {
    return req ? req.protocol + "://" + req.get("host") : "";
  }
  function authUser(req) {
    const h = req.headers.authorization || "";
    const m = /^Bearer\s+(.+)$/.exec(h);
    if (!m) return null;
    const s = store.sessions[m[1]];
    if (!s || s.expiresAt < Date.now()) return null;
    const user = store.users[s.handle];
    return user || null;
  }
  function requireAuth(req, res, next) {
    const u = authUser(req);
    if (!u) return res.status(401).json({ ok: false, error: "Sign in first — your @handle and password work on any device." });
    req.user = u;
    next();
  }
  function issueSession(handle) {
    const token = newToken();
    store.sessions[token] = { handle, createdAt: Date.now(), expiresAt: sessionExpiry() };
    return token;
  }
  async function persist() {
    // Store.mutate with a no-op serialises this write behind any in-flight one.
    await store.mutate(() => {});
  }

  // ---- health -----------------------------------------------------------
  app.get("/api/health", (req, res) => {
    res.json({ ok: true, service: "getraw-backend", tapes: store.tapes.length, users: Object.keys(store.users).length, uptimeSec: Math.floor(process.uptime()) });
  });

  // ---- auth -------------------------------------------------------------
  // Fans create a profile here. Artists do NOT use this — an artist's
  // profile is created at upload (see POST /api/tapes), exactly as the
  // site has always done it.
  app.post("/api/auth/register", rateLimit(20, 60000), async (req, res) => {
    const handle = normHandle(req.body.handle);
    const name = String(req.body.name || "").trim();
    const city = String(req.body.city || "").trim();
    const pw = String(req.body.password || "");
    if (!validHandle(handle)) return res.status(400).json({ ok: false, error: "Pick a valid @handle (letters, numbers, dots, dashes)." });
    if (!pw || pw.length < 6) return res.status(400).json({ ok: false, error: "Your password needs at least 6 characters." });
    // Email is optional — but if one is given it must be a real-looking
    // address, and opting in to promotions needs an email to send to.
    const email = normEmail(req.body.email);
    if (email && !validEmail(email)) return res.status(400).json({ ok: false, error: "Enter a valid email address — or leave it blank." });
    const promoOptIn = parsePromoOptIn(req.body.promoOptIn);
    if (promoOptIn && !email) return res.status(400).json({ ok: false, error: "Add an email address to get promotions from Get Raw." });
    if (store.users[handle]) return res.status(409).json({ ok: false, error: handle + " is already taken — sign in with it instead." });
    const user = { name: name || handle.slice(1), handle, passwordHash: hashPassword(pw), type: "fan", city, bio: "", avatarFile: "", cashtag: "", email, promoOptIn, downloads: [], uploads: [], createdAt: Date.now() };
    const token = await store.mutate(() => {
      store.users[handle] = user;
      return issueSession(handle);
    });
    res.status(201).json({ ok: true, token, user: privateUser(user, apiBase(req)) });
  });

  app.post("/api/auth/login", rateLimit(20, 60000), async (req, res) => {
    const handle = normHandle(req.body.handle);
    const pw = String(req.body.password || "");
    const user = store.users[handle];
    if (!user || !verifyPassword(pw, user.passwordHash)) {
      return res.status(401).json({ ok: false, error: "That @handle / password doesn't match — check it and try again." });
    }
    const token = await store.mutate(() => issueSession(handle));
    res.json({ ok: true, token, user: privateUser(user, apiBase(req)) });
  });

  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    const m = /^Bearer\s+(.+)$/.exec(req.headers.authorization || "");
    if (m) await store.mutate(() => { delete store.sessions[m[1]]; });
    res.json({ ok: true });
  });

  // Change password: the current password must match, the new one
  // needs at least 6 characters. Sessions stay valid — the user just
  // signs in with the new password next time.
  app.post("/api/auth/password", requireAuth, rateLimit(10, 60000), async (req, res) => {
    const u = req.user;
    const current = String((req.body && req.body.currentPassword) || "");
    const next = String((req.body && req.body.newPassword) || "");
    if (!current || !verifyPassword(current, u.passwordHash)) return res.status(401).json({ ok: false, error: "Your current password doesn't match." });
    if (!next || next.length < 6) return res.status(400).json({ ok: false, error: "Your new password needs at least 6 characters." });
    await store.mutate(() => { u.passwordHash = hashPassword(next); });
    res.json({ ok: true });
  });

  app.get("/api/auth/me", requireAuth, (req, res) => {
    const u = req.user;
    const myTapes = store.tapes.filter((t) => t.handle === u.handle).map((t) => publicTape(t, req));
    res.json({
      ok: true,
      user: privateUser(u, apiBase(req)),
      uploads: myTapes,
      downloads: (u.downloads || []).map((id) => publicTape(store.findTape(id), req)).filter(Boolean),
    });
  });

  app.patch("/api/auth/me", requireAuth, async (req, res) => {
    const u = req.user;
    const city = req.body.city !== undefined ? String(req.body.city || "").trim() : u.city;
    const name = req.body.name !== undefined ? String(req.body.name || "").trim() : u.name;
    const bio = req.body.bio !== undefined ? String(req.body.bio || "").trim().slice(0, 500) : (u.bio || "");
    const cashtag = req.body.cashtag !== undefined ? normCashtag(req.body.cashtag) : u.cashtag;
    // Email: an empty string clears it. Opting in needs an email on file
    // (the one sent now, or the one already stored).
    const email = req.body.email !== undefined ? normEmail(req.body.email) : (u.email || "");
    if (email && !validEmail(email)) return res.status(400).json({ ok: false, error: "Enter a valid email address — or leave it blank." });
    const promoOptIn = req.body.promoOptIn !== undefined ? parsePromoOptIn(req.body.promoOptIn) : !!u.promoOptIn;
    if (promoOptIn && !email) return res.status(400).json({ ok: false, error: "Add an email address to get promotions from Get Raw." });
    await store.mutate(() => {
      u.city = city; if (name) u.name = name; u.bio = bio; u.cashtag = cashtag;
      u.email = email; u.promoOptIn = promoOptIn;
      if (cashtag !== undefined) {
        for (const t of store.tapes) if (t.handle === u.handle) t.cashtag = cashtag;
      }
    });
    res.json({ ok: true, user: privateUser(u, apiBase(req)) });
  });

  // ---- profile photo ----------------------------------------------------
  // One photo per handle, shown on the owner's profile page and on the
  // public artist page (initial-letter fallback when there is none).
  // A new upload replaces the old file; deleting clears it.
  const MAX_AVATAR_BYTES = 5 * 1024 * 1024; // 5 MB profile photo
  const avatarStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(uploadsDir, "avatars", req.user.handle.slice(1));
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      cb(null, "avatar" + path.extname(file.originalname || "").toLowerCase());
    },
  });
  const avatarUpload = multer({
    storage: avatarStorage,
    limits: { fileSize: MAX_AVATAR_BYTES, files: 1 },
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      return IMAGE_EXTS[ext] ? cb(null, true) : cb(new Error("Profile photo must be a JPG, PNG, WebP or GIF image."));
    },
  });
  app.post("/api/auth/me/avatar", requireAuth, rateLimit(10, 60000), (req, res) => {
    avatarUpload.single("avatar")(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Photo upload failed." });
      if (!req.file) return res.status(400).json({ ok: false, error: "Choose a photo to upload." });
      const u = req.user;
      const oldFile = u.avatarFile ? path.join(uploadsDir, "avatars", u.handle.slice(1), u.avatarFile) : null;
      const newFile = path.join(uploadsDir, "avatars", u.handle.slice(1), req.file.filename);
      await store.mutate(() => { u.avatarFile = req.file.filename; });
      if (oldFile && oldFile !== newFile) {
        try { fs.rmSync(oldFile, { force: true }); } catch (_) {}
      }
      res.json({ ok: true, user: privateUser(u, apiBase(req)) });
    });
  });
  app.delete("/api/auth/me/avatar", requireAuth, async (req, res) => {
    const u = req.user;
    const oldFile = u.avatarFile ? path.join(uploadsDir, "avatars", u.handle.slice(1), u.avatarFile) : null;
    await store.mutate(() => { u.avatarFile = ""; });
    if (oldFile) {
      try { fs.rmSync(oldFile, { force: true }); } catch (_) {}
    }
    res.json({ ok: true, user: privateUser(u, apiBase(req)) });
  });

  // ---- deletes ----------------------------------------------------------
  // Remove one tape's files (cover + all tracks) from disk. The tape's
  // directory is uploads/<tapeId>/ and holds nothing else, so removing
  // the whole directory is safe. A missing dir is not an error.
  function deleteTapeFiles(tapeId) {
    try {
      fs.rmSync(path.join(uploadsDir, tapeId), { recursive: true, force: true });
    } catch (e) {
      console.error("delete tape files failed for " + tapeId + ":", e.message);
    }
  }
  // Remove a tape record and drop it from every user's saved downloads.
  // Callers delete the files separately (after the record is gone).
  function removeTapeRecord(tapeId) {
    store.tapes = store.tapes.filter((t) => t.id !== tapeId);
    for (const u of Object.values(store.users)) {
      if (Array.isArray(u.downloads)) u.downloads = u.downloads.filter((id) => id !== tapeId);
    }
  }

  // DELETE /api/auth/me — delete the whole account: the user record, ALL
  // their tapes (records + files), and all their sessions/tokens. Any
  // other user who saved one of their tapes loses that saved entry.
  // The frontend confirms twice before calling this — it cannot be undone.
  app.delete("/api/auth/me", requireAuth, async (req, res) => {
    const handle = req.user.handle;
    const tapeIds = store.tapes.filter((t) => t.handle === handle).map((t) => t.id);
    await store.mutate(() => {
      for (const id of tapeIds) removeTapeRecord(id);
      delete store.users[handle];
      for (const token of Object.keys(store.sessions)) {
        if (store.sessions[token].handle === handle) delete store.sessions[token];
      }
    });
    for (const id of tapeIds) deleteTapeFiles(id);
    res.json({ ok: true });
  });

  // ---- uploads ----------------------------------------------------------
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      // Tape id is assigned before multer runs (see upload middleware below)
      const dir = path.join(uploadsDir, req.tapeId);
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      const kind = file.fieldname === "cover" ? "cover" : "track";
      cb(null, kind + "-" + Date.now().toString(36) + "-" + crypto.randomBytes(4).toString("hex") + ext);
    },
  });
  const upload = multer({
    storage,
    limits: { fileSize: MAX_TRACK_BYTES, files: MAX_TRACKS + 1 },
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      if (file.fieldname === "cover") {
        return IMAGE_EXTS[ext] ? cb(null, true) : cb(new Error("Cover art must be a JPG, PNG, WebP or GIF image."));
      }
      if (file.fieldname === "tracks") {
        return AUDIO_EXTS[ext] ? cb(null, true) : cb(new Error("Audio tracks must be MP3, M4A, WAV, FLAC, OGG or AAC."));
      }
      return cb(new Error("Unexpected upload field: " + file.fieldname));
    },
  });

  // Create a tape (always starts as a private draft).
  // Artist rule, kept from the site: uploading creates the artist's
  // profile. First upload under a @handle sets its password; later
  // uploads under the same handle must use that password (or be signed
  // in as that handle).
  app.post("/api/tapes", rateLimit(10, 60000), (req, res, next) => {
    req.tapeId = tapeId();
    next();
  }, (req, res) => {
    upload.fields([{ name: "cover", maxCount: 1 }, { name: "tracks", maxCount: MAX_TRACKS }])(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Upload failed." });
      try {
        const b = req.body || {};
        const title = String(b.title || "").trim();
        const artist = String(b.artist || "").trim();
        const handle = normHandle(b.handle);
        const genre = String(b.genre || "").trim();
        const pw = String(b.password || "");
        const authed = authUser(req);
        if (!title || !artist || !validHandle(handle)) {
          return res.status(400).json({ ok: false, error: "Add a tape title, artist name, and artist @handle." });
        }
        if (!GENRES.includes(genre)) {
          return res.status(400).json({ ok: false, error: "Pick a genre — it puts the tape on the right chart." });
        }
        const trackFiles = (req.files && req.files.tracks) || [];
        if (!trackFiles.length) {
          return res.status(400).json({ ok: false, error: "Add at least one audio track." });
        }
        const titles = Array.isArray(b.trackTitles) ? b.trackTitles : (b.trackTitles ? [b.trackTitles] : []);
        const existing = store.users[handle];
        // Optional email + promo opt-in from the upload form (artist
        // profile creation). Same rules as register: a bad email is
        // rejected, opting in needs an email.
        const upEmail = normEmail(b.email);
        if (upEmail && !validEmail(upEmail)) {
          return res.status(400).json({ ok: false, error: "Enter a valid email address — or leave it blank." });
        }
        const upPromo = parsePromoOptIn(b.promoOptIn);
        if (upPromo && !upEmail && !(existing && existing.email)) {
          return res.status(400).json({ ok: false, error: "Add an email address to get promotions from Get Raw." });
        }
        let token = null;
        if (authed && authed.handle === handle) {
          token = null; // already signed in as this artist — no new token needed
        } else if (existing) {
          if (!pw || !verifyPassword(pw, existing.passwordHash)) {
            return res.status(401).json({ ok: false, error: "That password doesn't match the one already on " + handle + ". Enter the password you created for this handle, or upload under a different handle." });
          }
        } else {
          if (!pw || pw.length < 6) {
            return res.status(400).json({ ok: false, error: "Add an account password — first upload sets it for " + handle + ", and you sign in with your @handle and password." });
          }
        }
        const coverFile = req.files && req.files.cover && req.files.cover[0];
        // Explicit publish intent from the upload form ("Publish Now").
        // Anything else — including no flag at all — stays a private draft.
        const wantPublish = b.publish === "1" || b.publish === 1 || b.publish === true;
        const tape = {
          id: req.tapeId, title, artist, handle,
          dj: String(b.dj || "").trim(), genre,
          city: String(b.city || "").trim(), desc: String(b.desc || "").trim(),
          cashtag: normCashtag(b.cashtag),
          coverFile: coverFile ? coverFile.filename : null,
          tracks: trackFiles.map((f, i) => ({
            fileName: f.originalname, stored: f.filename,
            title: String((titles[i] || f.originalname || "").trim()) || f.originalname,
          })),
          releaseAt: null, draft: !wantPublish, featured: false,
          plays: 0, downloads: 0,
          // Fan reactions + comments (Nov 25): votes live on the tape
          // so the counts travel with it everywhere the music shows.
          votes: { up: 0, down: 0 }, voteBy: {}, comments: [],
          createdAt: Date.now(), publishedAt: wantPublish ? Date.now() : null,
        };
        const result = await store.mutate(() => {
          if (!existing) {
            store.users[handle] = {
              name: artist, handle, passwordHash: hashPassword(pw), type: "artist",
              city: tape.city, bio: "", avatarFile: "", cashtag: tape.cashtag, email: upEmail, promoOptIn: upPromo, downloads: [], uploads: [], createdAt: Date.now(),
            };
            token = issueSession(handle);
          } else {
            const u = store.users[handle];
            u.type = "artist";
            if (!u.name) u.name = artist;
            if (tape.cashtag) u.cashtag = tape.cashtag;
            if (!u.city && tape.city) u.city = tape.city;
            // Only touch email/promo if the upload form actually sent
            // them — a blank email field on a later upload must not
            // wipe the address already on the profile.
            if (upEmail) u.email = upEmail;
            if (b.promoOptIn !== undefined) u.promoOptIn = upPromo;
            if (!authed) token = issueSession(handle);
          }
          store.users[handle].uploads.push(tape.id);
          store.tapes.push(tape);
          return { token };
        });
        res.status(201).json({
          ok: true, tape: publicTape(tape, req),
          token: result.token || undefined,
          message: wantPublish ? "“" + title + "” is live in the Tapes feed now." : "“" + title + "” is saved as a private draft in your My Tapes, " + handle + " — only you can see it.",
        });
      } catch (e) {
        console.error("upload failed:", e);
        res.status(500).json({ ok: false, error: "Upload failed on the server — try again." });
      }
    });
  });

  // ---- tapes: read ------------------------------------------------------
  app.get("/api/tapes", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const q = String(req.query.search || "").trim().toLowerCase();
    const genre = String(req.query.genre || "");
    const mine = req.query.mine === "1";
    const user = authUser(req);
    let list = store.tapes.slice();
    if (mine) {
      if (!user) return res.status(401).json({ ok: false, error: "Sign in to see your tapes." });
      list = list.filter((t) => t.handle === user.handle);
    } else {
      list = list.filter(isLive);
    }
    if (genre) list = list.filter((t) => t.genre === genre);
    if (q) list = list.filter((t) => (t.title + " " + t.artist + " " + (t.dj || "") + " " + t.genre).toLowerCase().includes(q));
    list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    res.json({ ok: true, tapes: list.map((t) => publicTape(t, req)), total: list.length });
  });

  app.get("/api/tapes/:id", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t) return res.status(404).json({ ok: false, error: "No tape with that id." });
    const user = authUser(req);
    if (!isLive(t) && !(user && user.handle === t.handle)) {
      return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    }
    res.json({ ok: true, tape: publicTape(t, req) });
  });

  function ownTape(req, res) {
    const t = store.findTape(req.params.id);
    if (!t) { res.status(404).json({ ok: false, error: "No tape with that id." }); return null; }
    if (!req.user || req.user.handle !== t.handle) {
      res.status(403).json({ ok: false, error: "That's not your tape." });
      return null;
    }
    return t;
  }

  // Owner or admin (Kris) — the admin token can act on any tape, same
  // check as the Featured slot. Used by add-tracks and back-to-draft so
  // Kris can fix a tape from the server side too.
  function ownOrAdminTape(req, res) {
    const t = store.findTape(req.params.id);
    if (!t) { res.status(404).json({ ok: false, error: "No tape with that id." }); return null; }
    const isAdmin = !!ADMIN_TOKEN && req.headers["x-admin-token"] === ADMIN_TOKEN;
    const user = authUser(req);
    if (!isAdmin && (!user || user.handle !== t.handle)) {
      res.status(403).json({ ok: false, error: "That's not your tape." });
      return null;
    }
    return t;
  }

  app.post("/api/tapes/:id/publish", requireAuth, async (req, res) => {
    const t = ownTape(req, res); if (!t) return;
    await store.mutate(() => { t.draft = false; t.releaseAt = null; if (!t.publishedAt) t.publishedAt = Date.now(); });
    res.json({ ok: true, tape: publicTape(t, req), message: "“" + t.title + "” is live in the Tapes feed now." });
  });

  app.post("/api/tapes/:id/schedule", requireAuth, async (req, res) => {
    const t = ownTape(req, res); if (!t) return;
    const ts = new Date(req.body.releaseAt || "").getTime();
    if (isNaN(ts) || ts <= Date.now()) return res.status(400).json({ ok: false, error: "Pick a premiere time in the future." });
    await store.mutate(() => { t.draft = false; t.releaseAt = ts; if (!t.publishedAt) t.publishedAt = ts; });
    res.json({ ok: true, tape: publicTape(t, req), message: "Premiere scheduled for “" + t.title + "”." });
  });

  app.post("/api/tapes/:id/draft", async (req, res) => {
    const t = ownOrAdminTape(req, res); if (!t) return;
    await store.mutate(() => { t.draft = true; t.releaseAt = null; });
    res.json({ ok: true, tape: publicTape(t, req), message: "“" + t.title + "” is back to a private draft." });
  });

  // Add tracks to an existing tape (owner or admin). Appends in upload
  // order to the end of the track list; 20 tracks max per tape.
  app.post("/api/tapes/:id/tracks", rateLimit(10, 60000), (req, res, next) => {
    // Auth BEFORE multer runs, so a rejected request writes no files.
    const t = ownOrAdminTape(req, res);
    if (!t) return;
    req.tape = t;
    req.tapeId = t.id;
    next();
  }, (req, res) => {
    upload.fields([{ name: "tracks", maxCount: MAX_TRACKS }])(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Upload failed." });
      try {
        const t = req.tape;
        const trackFiles = (req.files && req.files.tracks) || [];
        if (!trackFiles.length) return res.status(400).json({ ok: false, error: "Add at least one audio track." });
        const existing = (t.tracks || []).length;
        if (existing + trackFiles.length > MAX_TRACKS) {
          trackFiles.forEach((f) => { try { fs.unlinkSync(path.join(uploadsDir, t.id, f.filename)); } catch (e) {} });
          return res.status(400).json({ ok: false, error: "20 tracks max per tape — this tape already has " + existing + ", so you can add " + (MAX_TRACKS - existing) + " more." });
        }
        const titles = Array.isArray(req.body.trackTitles) ? req.body.trackTitles : (req.body.trackTitles ? [req.body.trackTitles] : []);
        const added = trackFiles.map((f, i) => ({
          fileName: f.originalname, stored: f.filename,
          title: String((titles[i] || f.originalname || "").trim()) || f.originalname,
        }));
        await store.mutate(() => { t.tracks.push(...added); });
        res.status(201).json({ ok: true, tape: publicTape(t, req), added: added.length, message: "Added " + added.length + " track" + (added.length === 1 ? "" : "s") + " to “" + t.title + "” — it now has " + t.tracks.length + "." });
      } catch (e) {
        console.error("add tracks failed:", e);
        res.status(500).json({ ok: false, error: "Couldn't add those tracks — try again." });
      }
    });
  });

  // Edit a tape (owner or admin). Updates any field set at upload:
  // title, artist, DJ host, genre, city, description, $cashtag,
  // cover art (new file replaces the old one; removeCover clears it),
  // and each track's title (trackTitles, in track order — a blank
  // title keeps the current one). Tracks can also be removed
  // (removeTracks: track indexes — at least one track must remain;
  // removed audio files are deleted from disk). The @handle never
  // changes here — it is the account identity. Audio files are not
  // replaced in place; remove a track and use Add tracks for a new one.
  // Accepts multipart/form-data (cover upload) or JSON.
  app.patch("/api/tapes/:id", rateLimit(10, 60000), (req, res, next) => {
    // Auth BEFORE multer runs, so a rejected request writes no files.
    const t = ownOrAdminTape(req, res);
    if (!t) return;
    req.tape = t;
    req.tapeId = t.id;
    next();
  }, (req, res) => {
    upload.fields([{ name: "cover", maxCount: 1 }])(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Upload failed." });
      try {
        const t = req.tape;
        const b = req.body || {};
        const asList = (v) => {
          if (v === undefined || v === null) return [];
          if (Array.isArray(v)) return v;
          if (typeof v === "string" && v.trim().startsWith("[")) {
            try { const p = JSON.parse(v); return Array.isArray(p) ? p : [v]; } catch (_) { return [v]; }
          }
          return String(v).split(",").map((s) => s.trim()).filter((s) => s !== "");
        };
        const has = (k) => b[k] !== undefined && b[k] !== null;
        if (has("title") && !String(b.title || "").trim()) {
          return res.status(400).json({ ok: false, error: "Add a tape title." });
        }
        if (has("artist") && !String(b.artist || "").trim()) {
          return res.status(400).json({ ok: false, error: "Add an artist name." });
        }
        if (has("genre") && !GENRES.includes(String(b.genre || "").trim())) {
          return res.status(400).json({ ok: false, error: "Pick a genre — it puts the tape on the right chart." });
        }
        const removeIdx = asList(b.removeTracks).map((v) => Number(v)).filter((n) => Number.isInteger(n) && n >= 0 && n < (t.tracks || []).length);
        const uniqueRemove = [...new Set(removeIdx)];
        if (uniqueRemove.length && (t.tracks || []).length - uniqueRemove.length < 1) {
          return res.status(400).json({ ok: false, error: "A tape needs at least one track — keep one, or delete the whole tape instead." });
        }
        const coverFile = req.files && req.files.cover && req.files.cover[0];
        const removeCover = b.removeCover === true || b.removeCover === "1" || b.removeCover === "true";
        const oldCover = t.coverFile;
        const oldTracks = uniqueRemove.map((i) => t.tracks[i]).filter(Boolean);
        const titles = asList(b.trackTitles);
        await store.mutate(() => {
          if (has("title")) t.title = String(b.title).trim();
          if (has("artist")) t.artist = String(b.artist).trim();
          if (has("dj")) t.dj = String(b.dj || "").trim();
          if (has("genre")) t.genre = String(b.genre).trim();
          if (has("city")) t.city = String(b.city || "").trim();
          if (has("desc")) t.desc = String(b.desc || "").trim();
          if (has("cashtag")) t.cashtag = normCashtag(b.cashtag);
          titles.forEach((raw, i) => {
            const v = String(raw || "").trim();
            if (i < t.tracks.length && v) t.tracks[i].title = v;
          });
          if (uniqueRemove.length) {
            t.tracks = t.tracks.filter((_, i) => !uniqueRemove.includes(i));
          }
          if (coverFile) t.coverFile = coverFile.filename;
          else if (removeCover) t.coverFile = null;
        });
        // Delete replaced / removed files from disk (after the record saved).
        if (coverFile && oldCover && oldCover !== coverFile.filename) {
          try { fs.unlinkSync(path.join(uploadsDir, t.id, oldCover)); } catch (_) {}
        } else if (removeCover && !coverFile && oldCover) {
          try { fs.unlinkSync(path.join(uploadsDir, t.id, oldCover)); } catch (_) {}
        }
        for (const tr of oldTracks) {
          if (tr.stored) { try { fs.unlinkSync(path.join(uploadsDir, t.id, tr.stored)); } catch (_) {} }
        }
        res.json({ ok: true, tape: publicTape(t, req), message: "“" + t.title + "” is updated." });
      } catch (e) {
        console.error("edit tape failed:", e);
        res.status(500).json({ ok: false, error: "Couldn't save those edits — try again." });
      }
    });
  });

  // DELETE /api/tapes/:id — owner only. Deletes the tape record, its
  // cover + audio files, and drops it from every user's saved downloads.
  // The frontend confirms before calling this — it cannot be undone.
  app.delete("/api/tapes/:id", requireAuth, async (req, res) => {
    const t = ownTape(req, res); if (!t) return;
    const tapeId = t.id;
    await store.mutate(() => { removeTapeRecord(tapeId); });
    deleteTapeFiles(tapeId);
    res.json({ ok: true });
  });

  // Featured is a paid slot ($25) — only Kris (admin token) sets it.
  app.post("/api/admin/tapes/:id/featured", async (req, res) => {
    if (!ADMIN_TOKEN || req.headers["x-admin-token"] !== ADMIN_TOKEN) {
      return res.status(403).json({ ok: false, error: "Admin token required." });
    }
    const t = store.findTape(req.params.id);
    if (!t) return res.status(404).json({ ok: false, error: "No tape with that id." });
    await store.mutate(() => { t.featured = req.body.featured !== false; });
    res.json({ ok: true, tape: publicTape(t, req) });
  });

  // Promo mailing list (Kris only, same ADMIN_TOKEN as Featured).
  // Returns ONLY the @handle + email of users who opted in to
  // promotions and gave an email — nothing else about any account.
  // No other endpoint returns emails: publicUser() never includes one.
  app.get("/api/admin/promo-emails", async (req, res) => {
    if (!ADMIN_TOKEN || req.headers["x-admin-token"] !== ADMIN_TOKEN) {
      return res.status(403).json({ ok: false, error: "Admin token required." });
    }
    const emails = Object.values(store.users)
      .filter((u) => u.promoOptIn && u.email)
      .map((u) => ({ handle: u.handle, email: u.email }))
      .sort((a, b) => a.handle.localeCompare(b.handle));
    res.json({ ok: true, count: emails.length, emails });
  });

  // ---- plays & downloads (site-wide, kept separate) ---------------------
  app.post("/api/tapes/:id/play", rateLimit(60, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    await store.mutate(() => { t.plays = (t.plays || 0) + 1; });
    res.json({ ok: true, plays: t.plays, downloads: t.downloads });
  });

  app.post("/api/tapes/:id/download", rateLimit(60, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const user = authUser(req);
    await store.mutate(() => {
      t.downloads = (t.downloads || 0) + 1;
      if (user && !user.downloads.includes(t.id)) user.downloads.push(t.id);
    });
    res.json({ ok: true, plays: t.plays, downloads: t.downloads });
  });

  // ---- reactions + comments (fans with accounts, everywhere the music is) ------------
  // Liking and commenting need a signed-in account: the vote is keyed
  // by the fan's @handle, so every existing account gets this with no
  // re-registration. One vote per fan per tape; changing it moves the
  // count, "none" takes it back. Counts are absolute from the server.
  // Signed-out visitors get a 401 and the site shows them the
  // create-account popup instead of voting.
  function voteKey(req) {
    const user = authUser(req);
    if (!user) return null;
    return "h:" + user.handle;
  }
  app.post("/api/tapes/:id/react", rateLimit(60, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const vote = String((req.body && req.body.vote) || "").trim();
    if (vote !== "up" && vote !== "down" && vote !== "none") {
      return res.status(400).json({ ok: false, error: "Vote 'up', 'down', or 'none'." });
    }
    const key = voteKey(req);
    if (!key) return res.status(401).json({ ok: false, error: "Sign in to like this tape." });
    const out = await store.mutate(() => {
      if (!t.votes) t.votes = { up: 0, down: 0 };
      if (!t.voteBy) t.voteBy = {};
      const prev = t.voteBy[key] || "none";
      if (prev === vote) return { up: t.votes.up || 0, down: t.votes.down || 0, myVote: prev };
      if (prev === "up") t.votes.up = Math.max(0, (t.votes.up || 0) - 1);
      if (prev === "down") t.votes.down = Math.max(0, (t.votes.down || 0) - 1);
      if (vote === "up") t.votes.up = (t.votes.up || 0) + 1;
      if (vote === "down") t.votes.down = (t.votes.down || 0) + 1;
      if (vote === "none") delete t.voteBy[key]; else t.voteBy[key] = vote;
      return { up: t.votes.up || 0, down: t.votes.down || 0, myVote: vote };
    });
    res.json({ ok: true, up: out.up, down: out.down, myVote: out.myVote });
  });

  // Comments: newest first. The author is always the signed-in fan's
  // @handle. Text is capped at 500 characters and the tape keeps the
  // newest 500 comments. Signed-out visitors get a 401 and the site
  // shows them the create-account popup instead of posting.
  app.get("/api/tapes/:id/comments", (req, res) => {
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const list = (t.comments || []).slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    res.json({ ok: true, comments: list });
  });

  app.post("/api/tapes/:id/comments", rateLimit(10, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const user = authUser(req);
    if (!user) return res.status(401).json({ ok: false, error: "Sign in to comment." });
    const text = String((req.body && req.body.text) || "").trim();
    if (!text || text.length > 500) {
      return res.status(400).json({ ok: false, error: "Write a comment between 1 and 500 characters." });
    }
    const comment = { id: crypto.randomBytes(8).toString("hex"), name: user.handle, text, createdAt: Date.now() };
    await store.mutate(() => {
      if (!t.comments) t.comments = [];
      t.comments.push(comment);
      if (t.comments.length > 500) t.comments = t.comments.slice(-500);
    });
    res.status(201).json({ ok: true, comment });
  });

  // GET /api/tapes/:id/download-all — the whole tape as one ZIP file.
  // One click, one file. The download itself is counted by the POST
  // /download the button fires first, so this endpoint only streams.
  // Live tapes only. Each song is "01 - Title.mp3" in album order,
  // plus the cover art when the tape has one.
  app.get("/api/tapes/:id/download-all", rateLimit(10, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const tracks = t.tracks || [];
    if (!tracks.length) return res.status(404).json({ ok: false, error: "That tape has no songs yet." });
    const clean = (s) => String(s || "").replace(/[\\/:*?"<>|\x00-\x1f]/g, "").trim();
    const entries = [];
    for (let i = 0; i < tracks.length; i++) {
      const p = tapeFilePath(t, "track", i);
      if (!p || !fs.existsSync(p.file)) return res.status(500).json({ ok: false, error: "A song file is missing — the tape can't be zipped right now." });
      const ext = path.extname(p.name || tracks[i].stored || ".mp3") || ".mp3";
      const title = clean(tracks[i].title) || ("Track " + (i + 1));
      entries.push({ file: p.file, name: String(i + 1).padStart(2, "0") + " - " + title + ext });
    }
    const cover = tapeFilePath(t, "cover", 0);
    if (cover && fs.existsSync(cover.file)) entries.push({ file: cover.file, name: "cover" + (path.extname(cover.name || "") || ".jpg") });
    const zipName = clean(t.title) || "mixtape";
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="' + zipName + '.zip"');
    const archive = new ZipArchive({ zlib: { level: 6 } });
    archive.on("error", () => { try { res.destroy(); } catch (_) {} });
    archive.pipe(res);
    entries.forEach((e) => archive.file(e.file, { name: e.name }));
    await archive.finalize();
  });

  // ---- media: stream / download the actual files ------------------------
  // GET /api/media/:tapeId/cover — cover art.
  // GET /api/media/:tapeId/track/:idx — audio, with HTTP Range support so
  // the player can seek. ?download=1 sends it as an attachment (the
  // Android DownloadManager path and the web "Free download" button).
  function tapeFilePath(t, kind, idx) {
    if (!t) return null;
    if (kind === "cover") {
      if (!t.coverFile) return null;
      return { file: path.join(uploadsDir, t.id, t.coverFile), mime: IMAGE_EXTS[path.extname(t.coverFile).toLowerCase()] || "image/jpeg", name: t.coverFile };
    }
    const tr = (t.tracks || [])[idx];
    if (!tr) return null;
    return { file: path.join(uploadsDir, t.id, tr.stored), mime: AUDIO_EXTS[path.extname(tr.stored).toLowerCase()] || "audio/mpeg", name: tr.fileName };
  }
  function serveFile(req, res, t, kind, idx) {
    const target = tapeFilePath(t, kind, idx);
    if (!target) return res.status(404).json({ ok: false, error: "File not found." });
    const resolved = path.resolve(target.file);
    if (!resolved.startsWith(path.resolve(uploadsDir) + path.sep)) {
      return res.status(400).json({ ok: false, error: "Bad file path." });
    }
    fs.stat(resolved, (err, stat) => {
      if (err || !stat.isFile()) return res.status(404).json({ ok: false, error: "File not found." });
      const download = req.query.download === "1";
      const range = req.headers.range;
      if (range && !download) {
        const m = /^bytes=(\d*)-(\d*)$/.exec(range);
        if (m) {
          const start = m[1] ? parseInt(m[1], 10) : 0;
          const end = m[2] ? Math.min(parseInt(m[2], 10), stat.size - 1) : stat.size - 1;
          if (isNaN(start) || isNaN(end) || start > end || start >= stat.size) {
            res.status(416).setHeader("Content-Range", "bytes */" + stat.size).end();
            return;
          }
          res.status(206);
          res.setHeader("Content-Range", "bytes " + start + "-" + end + "/" + stat.size);
          res.setHeader("Accept-Ranges", "bytes");
          res.setHeader("Content-Length", end - start + 1);
          res.setHeader("Content-Type", target.mime);
          fs.createReadStream(resolved, { start, end }).pipe(res);
          return;
        }
      }
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", target.mime);
      res.setHeader("Accept-Ranges", "bytes");
      if (download) res.setHeader("Content-Disposition", 'attachment; filename="' + String(target.name).replace(/["\r\n]/g, "") + '"');
      fs.createReadStream(resolved).pipe(res);
    });
  }
  app.get("/api/media/:tapeId/cover", (req, res) => {
    const t = store.findTape(req.params.tapeId);
    if (!t) return res.status(404).json({ ok: false, error: "No tape with that id." });
    const user = authUser(req);
    if (!isLive(t) && !(user && user.handle === t.handle)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    serveFile(req, res, t, "cover", 0);
  });
  app.get("/api/media/:tapeId/track/:idx", (req, res) => {
    const idx = parseInt(req.params.idx, 10);
    if (isNaN(idx) || idx < 0) return res.status(400).json({ ok: false, error: "Bad track number." });
    const t = store.findTape(req.params.tapeId);
    if (!t) return res.status(404).json({ ok: false, error: "No tape with that id." });
    const user = authUser(req);
    if (!isLive(t) && !(user && user.handle === t.handle)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    serveFile(req, res, t, "track", idx);
  });

  // Public profile photo, by @handle (the @ is optional in the URL).
  app.get("/api/media/avatars/:handle", (req, res) => {
    const handle = normHandle(req.params.handle);
    const u = store.users[handle];
    if (!u || !u.avatarFile) return res.status(404).json({ ok: false, error: "No photo for that profile." });
    const file = path.join(uploadsDir, "avatars", handle.slice(1), u.avatarFile);
    const resolved = path.resolve(file);
    if (!resolved.startsWith(path.resolve(uploadsDir) + path.sep)) return res.status(400).json({ ok: false, error: "Bad file path." });
    fs.stat(resolved, (err, stat) => {
      if (err || !stat.isFile()) return res.status(404).json({ ok: false, error: "File not found." });
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", IMAGE_EXTS[path.extname(u.avatarFile).toLowerCase()] || "image/jpeg");
      fs.createReadStream(resolved).pipe(res);
    });
  });

  // ---- featured + artist of the week ------------------------------------
  app.get("/api/featured", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const live = store.tapes.filter(isLive);
    const featured = live.filter((t) => t.featured).map((t) => publicTape(t, req));
    const sorted = live.slice().sort((a, b) => ((b.plays || 0) + (b.downloads || 0)) - ((a.plays || 0) + (a.downloads || 0)));
    const aotw = sorted.length ? publicTape(sorted[0], req) : null;
    const soon = store.tapes.filter(isScheduled).sort((a, b) => a.releaseAt - b.releaseAt).map((t) => publicTape(t, req));
    res.json({ ok: true, featured, artistOfTheWeek: aotw, comingSoon: soon });
  });

  // ---- rankings -----------------------------------------------------------
  // mode: global (plays+downloads) | local (city, plays+downloads) |
  // plays | downloads | genre (genre filter, plays+downloads).
  app.get("/api/rankings", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const mode = String(req.query.mode || "global");
    const city = String(req.query.city || "").trim().toLowerCase();
    const genre = String(req.query.genre || "");
    let live = store.tapes.filter(isLive);
    let metric, label;
    if (mode === "plays") { metric = (t) => t.plays || 0; label = "plays"; }
    else if (mode === "downloads") { metric = (t) => t.downloads || 0; label = "downloads"; }
    else if (mode === "local") {
      live = live.filter((t) => (t.city || "").toLowerCase() === city);
      metric = (t) => (t.plays || 0) + (t.downloads || 0); label = "plays + downloads";
    } else if (mode === "genre") {
      live = live.filter((t) => t.genre === genre);
      metric = (t) => (t.plays || 0) + (t.downloads || 0); label = "plays + downloads";
    } else { metric = (t) => (t.plays || 0) + (t.downloads || 0); label = "plays + downloads"; }
    live.sort((a, b) => metric(b) - metric(a));
    res.json({ ok: true, mode, label, tapes: live.map((t) => publicTape(t, req)) });
  });

  // ---- year-end stats -----------------------------------------------------
  // Five boards, plays and downloads ALWAYS separate. Most Mixtapes counts
  // published tapes only — drafts never count. Year = the year a tape was
  // published (publishedAt, falling back to createdAt).
  app.get("/api/stats/year/:year", (req, res) => {
    const year = parseInt(req.params.year, 10);
    if (isNaN(year) || year < 2020 || year > 2100) return res.status(400).json({ ok: false, error: "Bad year." });
    const published = store.tapes.filter((t) => {
      if (t.draft) return false;
      const d = new Date(t.publishedAt || t.createdAt || 0);
      return d.getFullYear() === year;
    });
    const totalPlays = published.reduce((s, t) => s + (t.plays || 0), 0);
    const totalDownloads = published.reduce((s, t) => s + (t.downloads || 0), 0);
    const byPlays = published.slice().sort((a, b) => (b.plays || 0) - (a.plays || 0));
    const byDownloads = published.slice().sort((a, b) => (b.downloads || 0) - (a.downloads || 0));
    const artists = {};
    for (const t of published) {
      const key = (t.handle || t.artist || "").toLowerCase();
      if (!artists[key]) artists[key] = { artist: t.artist, handle: t.handle, plays: 0, downloads: 0, tapes: 0 };
      artists[key].plays += t.plays || 0;
      artists[key].downloads += t.downloads || 0;
      artists[key].tapes += 1;
    }
    const artistList = Object.values(artists);
    const top = (arr, field, min) => arr.filter((a) => (a[field] || 0) > (min || 0)).slice(0, 10).map((a) => ({ artist: a.artist, handle: a.handle, count: a[field] }));
    res.json({
      ok: true, year,
      totals: { plays: totalPlays, downloads: totalDownloads, publishedTapes: published.length },
      topTapesByPlays: byPlays.filter((t) => (t.plays || 0) > 0).slice(0, 10).map((t) => ({ title: t.title, artist: t.artist, handle: t.handle, count: t.plays })),
      topTapesByDownloads: byDownloads.filter((t) => (t.downloads || 0) > 0).slice(0, 10).map((t) => ({ title: t.title, artist: t.artist, handle: t.handle, count: t.downloads })),
      topArtistsByPlays: top(artistList.slice().sort((a, b) => b.plays - a.plays), "plays"),
      topArtistsByDownloads: top(artistList.slice().sort((a, b) => b.downloads - a.downloads), "downloads"),
      mostMixtapes: artistList.slice().sort((a, b) => b.tapes - a.tapes).filter((a) => a.tapes > 0).slice(0, 10).map((a) => ({ artist: a.artist, handle: a.handle, count: a.tapes })),
    });
  });

  // ---- public artist profile ----------------------------------------------
  app.get("/api/artists/:handle", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const handle = normHandle(req.params.handle);
    const user = store.users[handle];
    if (!user) return res.status(404).json({ ok: false, error: "No profile for " + handle + " yet." });
    const live = store.tapes.filter((t) => t.handle === handle && isLive(t)).map((t) => publicTape(t, req));
    res.json({
      ok: true,
      profile: publicUser(user, apiBase(req)),
      tapes: live,
      totals: { plays: live.reduce((s, t) => s + t.plays, 0), downloads: live.reduce((s, t) => s + t.downloads, 0), publishedTapes: live.length },
    });
  });

  app.get("/api/genres", (req, res) => res.json({ ok: true, genres: GENRES }));

  // 404 + error handler (JSON, never an HTML stack trace).
  app.use((req, res) => res.status(404).json({ ok: false, error: "No such endpoint: " + req.method + " " + req.path }));
  app.use((err, req, res, _next) => {
    console.error("error:", err && err.message);
    res.status(500).json({ ok: false, error: "Server error — try again." });
  });

  return { app, store };
}

if (require.main === module) {
  const { app } = createApp();
  app.listen(PORT, () => {
    console.log("getraw-backend listening on :" + PORT + " (data: " + DATA_DIR + ", uploads: " + UPLOADS_DIR + ")");
  });
}

module.exports = { createApp };
