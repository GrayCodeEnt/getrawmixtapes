// Get Raw Mixtapes — shared backend (Node + Express).
//
// This is what makes the site real: artists upload once, everyone can
// listen, and a user can log in on any phone or computer and see their
// own profile, tapes and drafts.
//
//   * Auth: @handle + password (scrypt-hashed, lib/auth.js), token
//     sessions stored server-side — the token works from any device.
//   * Tapes: drafts, Publish Now, Schedule a Premiere, live feed,
//     search + genre filter, Featured, Artist of the Week, Rankings
//     (Global / Local / Most Plays / Most Downloads / genre) and
//     Year-End stats. Plays and downloads are counted site-wide and
//     kept SEPARATE everywhere, never mixed.
//     Edit: PATCH /api/tapes/:id (owner only) updates any uploaded
//     field — title, artist, DJ, genre, city, description, $cashtag,
//     cover art, and each track's title — and can remove tracks.
//     Delete: DELETE /api/tapes/:id (owner only) and DELETE
//     /api/auth/me (whole account + all its tapes) remove the record,
//     the files on disk, and the tape from saved downloads.
//   * Email (optional): a user may give an email + tick "send me
//     promotions" at sign-up, on upload, or in their profile. It is
//     private — never in any public response — and Kris can list the
//     opted-in addresses via GET /api/admin/promo-emails (admin token).
//   * Profiles: the owner can edit name, city, bio and photo, and
//     change their password (current password required) — all from
//     their profile page. Photos live under uploads/avatars/<handle>/
//     and are served at /api/media/avatars/<handle>.
//   * Files: cover art + audio tracks are stored on this server's disk
//     (uploads/<tapeId>/), streamed with HTTP Range support so the
//     <audio> player can seek, and downloadable via DownloadManager.
//   * Data: plain JSON files in data/ (users.json, tapes.json,
//     sessions.json) — same durable pattern as the Hoopty backend.
//     No paid database, no third-party service.
//
// Separation from Hoopty (Kris, Nov 19, 2026): this service is
// COMPLETELY separate — its own directory (/opt/getraw), its own data
// (/opt/getraw/data), its own uploads (/opt/getraw/uploads), its own
// systemd unit (getraw), its own port (3001 — Hoopty is 3000) and its
// own address (https://api.getrawmixtapes.com — Hoopty is
// api.hoopty.rent). Nothing here reads or writes /opt/hoopty.
//
// RUN (local / deploy): npm install && npm start
//   PORT           default 3001
//   DATA_DIR       default ./data
//   UPLOADS_DIR    default ./uploads
//   FRONTEND_URL   default https://getrawmixtapes.com (CORS origin)
//   ADMIN_TOKEN    secret for the Featured-slot endpoint (set at deploy;
//                  if unset, that endpoint stays disabled)
//   SESSION_DAYS   default 30
"use strict";

const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const multer = require("multer");
const { ZipArchive } = require("archiver");
const { Store } = require("./lib/store");
const { hashPassword, verifyPassword, newToken, sessionExpiry, publicUser, privateUser, normEmail, validEmail } = require("./lib/auth");

const PORT = Number(process.env.PORT || 3001);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const UPLOADS_DIR = process.env.UPLOADS_DIR || path.join(__dirname, "uploads");
const FRONTEND_URL = (process.env.FRONTEND_URL || "https://getrawmixtapes.com").replace(/\/$/, "");
const GENRES = ["Hip-Hop", "Rap", "Trap", "Drill", "Boom Bap", "R&B", "Afrobeats", "Dancehall", "Grime", "Underground", "Other"];

const AUDIO_EXTS = { ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".wav": "audio/wav", ".flac": "audio/flac", ".ogg": "audio/ogg", ".aac": "audio/aac" };
const IMAGE_EXTS = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif" };
const MAX_TRACKS = 20;
const MAX_TRACK_BYTES = 150 * 1024 * 1024; // 150 MB per track
const MAX_COVER_BYTES = 10 * 1024 * 1024;  // 10 MB cover art
const VIDEO_EXTS = { ".mp4": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm", ".m4v": "video/x-m4v" };
const MAX_FEED_IMAGE_BYTES = 10 * 1024 * 1024;  // 10 MB per Trenches photo — same as cover art
const MAX_FEED_VIDEO_BYTES = 100 * 1024 * 1024; // 100 MB per Trenches video

function createApp(opts) {
  const store = new Store((opts && opts.dataDir) || DATA_DIR);
  const uploadsDir = (opts && opts.uploadsDir) || UPLOADS_DIR;
  // Admin token: from the server .env in production; tests may pass
  // opts.adminToken so the promo-emails endpoint can be exercised.
  const ADMIN_TOKEN = (opts && opts.adminToken) || process.env.ADMIN_TOKEN || "";
  fs.mkdirSync(uploadsDir, { recursive: true });
  const app = express();
  app.disable("x-powered-by");
  // Behind nginx/Caddy (TLS ends at the proxy): trust X-Forwarded-Proto
  // so media URLs we build are https://, not http://.
  app.set("trust proxy", 1);
  app.use(express.json({ limit: "1mb" }));

  // CORS: the static site on getrawmixtapes.com (and the app, which loads
  // that site) is the only browser origin. curl / server-to-server calls
  // have no Origin and are allowed through.
  const ALLOWED_ORIGINS = new Set([FRONTEND_URL, "https://www.getrawmixtapes.com", "http://localhost:3000", "http://127.0.0.1:3000"]);
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && ALLOWED_ORIGINS.has(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
    } else if (origin && /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
    }
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
    if (req.method === "OPTIONS") return res.sendStatus(204);
    next();
  });

  // ---- tiny in-memory rate limits (per IP, per minute) -----------------
  const buckets = new Map();
  function rateLimit(max, windowMs) {
    return (req, res, next) => {
      const key = (req.ip || "x") + ":" + req.path;
      const now = Date.now();
      const b = buckets.get(key) || { count: 0, start: now };
      if (now - b.start > windowMs) { b.count = 0; b.start = now; }
      b.count += 1;
      buckets.set(key, b);
      if (b.count > max) return res.status(429).json({ ok: false, error: "Too many requests — slow down and try again." });
      next();
    };
  }

  // ---- helpers ----------------------------------------------------------
  function normHandle(h) {
    h = String(h || "").trim().toLowerCase();
    if (h && h.charAt(0) !== "@") h = "@" + h;
    return h.replace(/\s+/g, "");
  }
  function validHandle(h) {
    return /^@[a-z0-9._-]{2,32}$/.test(h || "");
  }
  // Promo opt-in arrives as a JSON boolean, or as a form string ("1" /
  // "true" from the upload form). Anything else counts as off.
  function parsePromoOptIn(v) {
    return v === true || v === 1 || v === "1" || v === "true";
  }
  function normCashtag(c) {
    c = String(c || "").trim().replace(/\s+/g, "");
    if (!c) return "";
    if (c.charAt(0) !== "$") c = "$" + c;
    return c.length > 1 ? c : "";
  }
  function tapeId() {
    return "t_" + Date.now().toString(36) + "_" + crypto.randomBytes(6).toString("hex");
  }
  function isLive(t) {
    return !t.draft && (!t.releaseAt || t.releaseAt <= Date.now());
  }
  function isScheduled(t) {
    return !t.draft && !!t.releaseAt && t.releaseAt > Date.now();
  }
  // Premieres whose time has come go live (persisted on next write; the
  // read path treats them as live immediately so nobody misses a drop).
  function sweepPremieres() {
    let changed = false;
    const now = Date.now();
    for (const t of store.tapes) {
      if (!t.draft && t.releaseAt && t.releaseAt <= now) {
        t.releaseAt = null;
        if (!t.publishedAt) t.publishedAt = now;
        changed = true;
      }
    }
    return changed;
  }
  function publicTape(t, req) {
    const base = (req ? req.protocol + "://" + req.get("host") : "");
    // The artist's profile picture, so the site can show it next to
    // their name on tape cards, the tape dialog, Artist of the Week
    // and the charts. Empty until the artist uploads a photo.
    const owner = store.users[t.handle];
    const artistAvatar = owner && owner.avatarFile && base ? base + "/api/media/avatars/" + t.handle.slice(1) : "";
    return {
      id: t.id, title: t.title, artist: t.artist, handle: t.handle,
      artistAvatar,
      dj: t.dj || "", genre: t.genre, city: t.city || "", desc: t.desc || "",
      cover: t.coverFile ? base + "/api/media/" + t.id + "/cover" : null,
      coverUrl: t.coverFile ? base + "/api/media/" + t.id + "/cover" : null,
      tracks: (t.tracks || []).map((tr, i) => ({
        idx: i, title: tr.title, fileName: tr.fileName,
        url: base + "/api/media/" + t.id + "/track/" + i,
        downloadUrl: base + "/api/media/" + t.id + "/track/" + i + "?download=1",
      })),
      releaseAt: t.releaseAt || null, draft: !!t.draft,
      featured: !!t.featured, plays: t.plays || 0, downloads: t.downloads || 0,
      // Fan reactions: counts only — voteBy (who voted) never leaves
      // the server, and comments travel on their own endpoint.
      up: (t.votes && t.votes.up) || 0, down: (t.votes && t.votes.down) || 0,
      commentCount: (t.comments || []).length,
      cashtag: normCashtag(t.cashtag || ""),
      createdAt: t.createdAt, publishedAt: t.publishedAt || null,
    };
  }
  function apiBase(req) {
    return req ? req.protocol + "://" + req.get("host") : "";
  }
  function authUser(req) {
    const h = req.headers.authorization || "";
    const m = /^Bearer\s+(.+)$/.exec(h);
    if (!m) return null;
    const s = store.sessions[m[1]];
    if (!s || s.expiresAt < Date.now()) return null;
    const user = store.users[s.handle];
    return user || null;
  }
  // Same session check, but also accepts ?token= — file downloads open
  // as plain links (a browser anchor, or the Android DownloadManager),
  // which carry no Authorization header, so the signed-in frontend
  // appends its own token to the download URL. Same sessions store,
  // same expiry, same user — guests have no token, so they get a 401.
  function authUserOrQuery(req) {
    const u = authUser(req);
    if (u) return u;
    const tok = String((req.query && req.query.token) || "");
    if (!tok) return null;
    const s = store.sessions[tok];
    if (!s || s.expiresAt < Date.now()) return null;
    return store.users[s.handle] || null;
  }
  function requireAuth(req, res, next) {
    const u = authUser(req);
    if (!u) return res.status(401).json({ ok: false, error: "Sign in first — your @handle and password work on any device." });
    req.user = u;
    next();
  }
  function requireAuthOrQuery(req, res, next) {
    const u = authUserOrQuery(req);
    if (!u) return res.status(401).json({ ok: false, error: "Sign in first — your @handle and password work on any device." });
    req.user = u;
    next();
  }
  function issueSession(handle) {
    const token = newToken();
    store.sessions[token] = { handle, createdAt: Date.now(), expiresAt: sessionExpiry() };
    return token;
  }
  async function persist() {
    // Store.mutate with a no-op serialises this write behind any in-flight one.
    await store.mutate(() => {});
  }

  // ---- health -----------------------------------------------------------
  app.get("/api/health", (req, res) => {
    res.json({ ok: true, service: "getraw-backend", tapes: store.tapes.length, users: Object.keys(store.users).length, uptimeSec: Math.floor(process.uptime()) });
  });

  // ---- auth -------------------------------------------------------------
  // Fans create a profile here. Artists do NOT use this — an artist's
  // profile is created at upload (see POST /api/tapes), exactly as the
  // site has always done it.
  app.post("/api/auth/register", rateLimit(20, 60000), async (req, res) => {
    const handle = normHandle(req.body.handle);
    const name = String(req.body.name || "").trim();
    const city = String(req.body.city || "").trim();
    const pw = String(req.body.password || "");
    if (!validHandle(handle)) return res.status(400).json({ ok: false, error: "Pick a valid @handle (letters, numbers, dots, dashes)." });
    if (!pw || pw.length < 6) return res.status(400).json({ ok: false, error: "Your password needs at least 6 characters." });
    // Email is optional — but if one is given it must be a real-looking
    // address, and opting in to promotions needs an email to send to.
    const email = normEmail(req.body.email);
    if (email && !validEmail(email)) return res.status(400).json({ ok: false, error: "Enter a valid email address — or leave it blank." });
    const promoOptIn = parsePromoOptIn(req.body.promoOptIn);
    if (promoOptIn && !email) return res.status(400).json({ ok: false, error: "Add an email address to get promotions from Get Raw." });
    if (store.users[handle]) return res.status(409).json({ ok: false, error: handle + " is already taken — sign in with it instead." });
    const user = { name: name || handle.slice(1), handle, passwordHash: hashPassword(pw), type: "fan", city, bio: "", avatarFile: "", cashtag: "", email, promoOptIn, downloads: [], uploads: [], playlists: [], createdAt: Date.now() };
    const token = await store.mutate(() => {
      store.users[handle] = user;
      return issueSession(handle);
    });
    res.status(201).json({ ok: true, token, user: privateUser(user, apiBase(req)) });
  });

  app.post("/api/auth/login", rateLimit(20, 60000), async (req, res) => {
    const handle = normHandle(req.body.handle);
    const pw = String(req.body.password || "");
    const user = store.users[handle];
    if (!user || !verifyPassword(pw, user.passwordHash)) {
      return res.status(401).json({ ok: false, error: "That @handle / password doesn't match — check it and try again." });
    }
    const token = await store.mutate(() => issueSession(handle));
    res.json({ ok: true, token, user: privateUser(user, apiBase(req)) });
  });

  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    const m = /^Bearer\s+(.+)$/.exec(req.headers.authorization || "");
    if (m) await store.mutate(() => { delete store.sessions[m[1]]; });
    res.json({ ok: true });
  });

  // Change password: the current password must match, the new one
  // needs at least 6 characters. Sessions stay valid — the user just
  // signs in with the new password next time.
  app.post("/api/auth/password", requireAuth, rateLimit(10, 60000), async (req, res) => {
    const u = req.user;
    const current = String((req.body && req.body.currentPassword) || "");
    const next = String((req.body && req.body.newPassword) || "");
    if (!current || !verifyPassword(current, u.passwordHash)) return res.status(401).json({ ok: false, error: "Your current password doesn't match." });
    if (!next || next.length < 6) return res.status(400).json({ ok: false, error: "Your new password needs at least 6 characters." });
    await store.mutate(() => { u.passwordHash = hashPassword(next); });
    res.json({ ok: true });
  });

  app.get("/api/auth/me", requireAuth, (req, res) => {
    const u = req.user;
    const myTapes = store.tapes.filter((t) => t.handle === u.handle).map((t) => publicTape(t, req));
    res.json({
      ok: true,
      user: privateUser(u, apiBase(req)),
      uploads: myTapes,
      downloads: (u.downloads || []).map((id) => publicTape(store.findTape(id), req)).filter(Boolean),
    });
  });

  app.patch("/api/auth/me", requireAuth, async (req, res) => {
    const u = req.user;
    const city = req.body.city !== undefined ? String(req.body.city || "").trim() : u.city;
    const name = req.body.name !== undefined ? String(req.body.name || "").trim() : u.name;
    const bio = req.body.bio !== undefined ? String(req.body.bio || "").trim().slice(0, 500) : (u.bio || "");
    const cashtag = req.body.cashtag !== undefined ? normCashtag(req.body.cashtag) : u.cashtag;
    // Email: an empty string clears it. Opting in needs an email on file
    // (the one sent now, or the one already stored).
    const email = req.body.email !== undefined ? normEmail(req.body.email) : (u.email || "");
    if (email && !validEmail(email)) return res.status(400).json({ ok: false, error: "Enter a valid email address — or leave it blank." });
    const promoOptIn = req.body.promoOptIn !== undefined ? parsePromoOptIn(req.body.promoOptIn) : !!u.promoOptIn;
    if (promoOptIn && !email) return res.status(400).json({ ok: false, error: "Add an email address to get promotions from Get Raw." });
    // Private profile: only the owner and their followers see the wall.
    // Default is public — the toggle is in the Edit profile card.
    const isPrivate = req.body.isPrivate !== undefined ? !!req.body.isPrivate : !!u.isPrivate;
    await store.mutate(() => {
      u.city = city; if (name) u.name = name; u.bio = bio; u.cashtag = cashtag;
      u.email = email; u.promoOptIn = promoOptIn; u.isPrivate = isPrivate;
      if (cashtag !== undefined) {
        for (const t of store.tapes) if (t.handle === u.handle) t.cashtag = cashtag;
      }
    });
    res.json({ ok: true, user: privateUser(u, apiBase(req)) });
  });

  // ---- profile photo ----------------------------------------------------
  // One photo per handle, shown on the owner's profile page and on the
  // public artist page (initial-letter fallback when there is none).
  // A new upload replaces the old file; deleting clears it.
  const MAX_AVATAR_BYTES = 5 * 1024 * 1024; // 5 MB profile photo
  const avatarStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(uploadsDir, "avatars", req.user.handle.slice(1));
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      cb(null, "avatar" + path.extname(file.originalname || "").toLowerCase());
    },
  });
  const avatarUpload = multer({
    storage: avatarStorage,
    limits: { fileSize: MAX_AVATAR_BYTES, files: 1 },
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      return IMAGE_EXTS[ext] ? cb(null, true) : cb(new Error("Profile photo must be a JPG, PNG, WebP or GIF image."));
    },
  });
  app.post("/api/auth/me/avatar", requireAuth, rateLimit(10, 60000), (req, res) => {
    avatarUpload.single("avatar")(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Photo upload failed." });
      if (!req.file) return res.status(400).json({ ok: false, error: "Choose a photo to upload." });
      const u = req.user;
      const oldFile = u.avatarFile ? path.join(uploadsDir, "avatars", u.handle.slice(1), u.avatarFile) : null;
      const newFile = path.join(uploadsDir, "avatars", u.handle.slice(1), req.file.filename);
      await store.mutate(() => { u.avatarFile = req.file.filename; });
      if (oldFile && oldFile !== newFile) {
        try { fs.rmSync(oldFile, { force: true }); } catch (_) {}
      }
      res.json({ ok: true, user: privateUser(u, apiBase(req)) });
    });
  });
  app.delete("/api/auth/me/avatar", requireAuth, async (req, res) => {
    const u = req.user;
    const oldFile = u.avatarFile ? path.join(uploadsDir, "avatars", u.handle.slice(1), u.avatarFile) : null;
    await store.mutate(() => { u.avatarFile = ""; });
    if (oldFile) {
      try { fs.rmSync(oldFile, { force: true }); } catch (_) {}
    }
    res.json({ ok: true, user: privateUser(u, apiBase(req)) });
  });

  // ---- deletes ----------------------------------------------------------
  // Remove one tape's files (cover + all tracks) from disk. The tape's
  // directory is uploads/<tapeId>/ and holds nothing else, so removing
  // the whole directory is safe. A missing dir is not an error.
  function deleteTapeFiles(tapeId) {
    try {
      fs.rmSync(path.join(uploadsDir, tapeId), { recursive: true, force: true });
    } catch (e) {
      console.error("delete tape files failed for " + tapeId + ":", e.message);
    }
  }
  // Remove a tape record and drop it from every user's saved downloads
  // and playlists (a deleted song cannot stay in a library).
  function removeTapeRecord(tapeId) {
    store.tapes = store.tapes.filter((t) => t.id !== tapeId);
    for (const u of Object.values(store.users)) {
      if (Array.isArray(u.downloads)) u.downloads = u.downloads.filter((id) => id !== tapeId);
      if (Array.isArray(u.playlists)) for (const pl of u.playlists) pl.items = (pl.items || []).filter((it) => it.tapeId !== tapeId);
    }
  }

  // DELETE /api/auth/me — delete the whole account: the user record, ALL
  // their tapes (records + files), their Trenches posts (records +
  // media), wall posts on their wall (records + media, whoever posted
  // them), and all their sessions/tokens. Follows and notifications
  // naming them are cleaned up too. Any other user who saved one of
  // their tapes loses that saved entry.
  // The frontend confirms twice before calling this — it cannot be undone.
  app.delete("/api/auth/me", requireAuth, async (req, res) => {
    const handle = req.user.handle;
    const tapeIds = store.tapes.filter((t) => t.handle === handle).map((t) => t.id);
    const postIds = store.posts.filter((p) => p.author === handle || p.wall === handle).map((p) => p.id);
    await store.mutate(() => {
      for (const id of tapeIds) removeTapeRecord(id);
      store.posts = store.posts.filter((p) => p.author !== handle && p.wall !== handle);
      for (const u of Object.values(store.users)) {
        if (Array.isArray(u.followers)) u.followers = u.followers.filter((h) => h !== handle);
        if (Array.isArray(u.following)) u.following = u.following.filter((h) => h !== handle);
      }
      store.notifications = store.notifications.filter((n) => n.to !== handle && n.from !== handle);
      delete store.users[handle];
      for (const token of Object.keys(store.sessions)) {
        if (store.sessions[token].handle === handle) delete store.sessions[token];
      }
    });
    for (const id of tapeIds) deleteTapeFiles(id);
    for (const id of postIds) {
      try { fs.rmSync(path.join(uploadsDir, "feed", id), { recursive: true, force: true }); } catch (_) {}
    }
    res.json({ ok: true });
  });

  // ---- uploads ----------------------------------------------------------
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      // Tape id is assigned before multer runs (see upload middleware below)
      const dir = path.join(uploadsDir, req.tapeId);
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      const kind = file.fieldname === "cover" ? "cover" : "track";
      cb(null, kind + "-" + Date.now().toString(36) + "-" + crypto.randomBytes(4).toString("hex") + ext);
    },
  });
  const upload = multer({
    storage,
    limits: { fileSize: MAX_TRACK_BYTES, files: MAX_TRACKS + 1 },
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      if (file.fieldname === "cover") {
        return IMAGE_EXTS[ext] ? cb(null, true) : cb(new Error("Cover art must be a JPG, PNG, WebP or GIF image."));
      }
      if (file.fieldname === "tracks") {
        return AUDIO_EXTS[ext] ? cb(null, true) : cb(new Error("Audio tracks must be MP3, M4A, WAV, FLAC, OGG or AAC."));
      }
      return cb(new Error("Unexpected upload field: " + file.fieldname));
    },
  });

  // Create a tape (always starts as a private draft).
  // Artist rule, kept from the site: uploading creates the artist's
  // profile. First upload under a @handle sets its password; later
  // uploads under the same handle must use that password (or be signed
  // in as that handle).
  app.post("/api/tapes", rateLimit(10, 60000), (req, res, next) => {
    req.tapeId = tapeId();
    next();
  }, (req, res) => {
    upload.fields([{ name: "cover", maxCount: 1 }, { name: "tracks", maxCount: MAX_TRACKS }])(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Upload failed." });
      try {
        const b = req.body || {};
        const title = String(b.title || "").trim();
        const artist = String(b.artist || "").trim();
        const handle = normHandle(b.handle);
        const genre = String(b.genre || "").trim();
        const pw = String(b.password || "");
        const authed = authUser(req);
        if (!title || !artist || !validHandle(handle)) {
          return res.status(400).json({ ok: false, error: "Add a tape title, artist name, and artist @handle." });
        }
        if (!GENRES.includes(genre)) {
          return res.status(400).json({ ok: false, error: "Pick a genre — it puts the tape on the right chart." });
        }
        const trackFiles = (req.files && req.files.tracks) || [];
        if (!trackFiles.length) {
          return res.status(400).json({ ok: false, error: "Add at least one audio track." });
        }
        const titles = Array.isArray(b.trackTitles) ? b.trackTitles : (b.trackTitles ? [b.trackTitles] : []);
        const existing = store.users[handle];
        // Optional email + promo opt-in from the upload form (artist
        // profile creation). Same rules as register: a bad email is
        // rejected, opting in needs an email.
        const upEmail = normEmail(b.email);
        if (upEmail && !validEmail(upEmail)) {
          return res.status(400).json({ ok: false, error: "Enter a valid email address — or leave it blank." });
        }
        const upPromo = parsePromoOptIn(b.promoOptIn);
        if (upPromo && !upEmail && !(existing && existing.email)) {
          return res.status(400).json({ ok: false, error: "Add an email address to get promotions from Get Raw." });
        }
        let token = null;
        if (authed && authed.handle === handle) {
          token = null; // already signed in as this artist — no new token needed
        } else if (existing) {
          if (!pw || !verifyPassword(pw, existing.passwordHash)) {
            return res.status(401).json({ ok: false, error: "That password doesn't match the one already on " + handle + ". Enter the password you created for this handle, or upload under a different handle." });
          }
        } else {
          if (!pw || pw.length < 6) {
            return res.status(400).json({ ok: false, error: "Add an account password — first upload sets it for " + handle + ", and you sign in with your @handle and password." });
          }
        }
        const coverFile = req.files && req.files.cover && req.files.cover[0];
        // Explicit publish intent from the upload form ("Publish Now").
        // Anything else — including no flag at all — stays a private draft.
        const wantPublish = b.publish === "1" || b.publish === 1 || b.publish === true;
        const tape = {
          id: req.tapeId, title, artist, handle,
          dj: String(b.dj || "").trim(), genre,
          city: String(b.city || "").trim(), desc: String(b.desc || "").trim(),
          cashtag: normCashtag(b.cashtag),
          coverFile: coverFile ? coverFile.filename : null,
          tracks: trackFiles.map((f, i) => ({
            fileName: f.originalname, stored: f.filename,
            title: String((titles[i] || f.originalname || "").trim()) || f.originalname,
          })),
          releaseAt: null, draft: !wantPublish, featured: false,
          plays: 0, downloads: 0,
          // Fan reactions + comments (Nov 25): votes live on the tape
          // so the counts travel with it everywhere the music shows.
          votes: { up: 0, down: 0 }, voteBy: {}, comments: [],
          createdAt: Date.now(), publishedAt: wantPublish ? Date.now() : null,
        };
        const result = await store.mutate(() => {
          if (!existing) {
            store.users[handle] = {
              name: artist, handle, passwordHash: hashPassword(pw), type: "artist",
              city: tape.city, bio: "", avatarFile: "", cashtag: tape.cashtag, email: upEmail, promoOptIn: upPromo, downloads: [], uploads: [], playlists: [], createdAt: Date.now(),
            };
            token = issueSession(handle);
          } else {
            const u = store.users[handle];
            u.type = "artist";
            if (!u.name) u.name = artist;
            if (tape.cashtag) u.cashtag = tape.cashtag;
            if (!u.city && tape.city) u.city = tape.city;
            // Only touch email/promo if the upload form actually sent
            // them — a blank email field on a later upload must not
            // wipe the address already on the profile.
            if (upEmail) u.email = upEmail;
            if (b.promoOptIn !== undefined) u.promoOptIn = upPromo;
            if (!authed) token = issueSession(handle);
          }
          store.users[handle].uploads.push(tape.id);
          store.tapes.push(tape);
          return { token };
        });
        res.status(201).json({
          ok: true, tape: publicTape(tape, req),
          token: result.token || undefined,
          message: wantPublish ? "“" + title + "” is live in the Tapes feed now." : "“" + title + "” is saved as a private draft in your My Tapes, " + handle + " — only you can see it.",
        });
      } catch (e) {
        console.error("upload failed:", e);
        res.status(500).json({ ok: false, error: "Upload failed on the server — try again." });
      }
    });
  });

  // ---- tapes: read ------------------------------------------------------
  app.get("/api/tapes", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const q = String(req.query.search || "").trim().toLowerCase();
    const genre = String(req.query.genre || "");
    const mine = req.query.mine === "1";
    const user = authUser(req);
    let list = store.tapes.slice();
    if (mine) {
      if (!user) return res.status(401).json({ ok: false, error: "Sign in to see your tapes." });
      list = list.filter((t) => t.handle === user.handle);
    } else {
      list = list.filter(isLive);
    }
    if (genre) list = list.filter((t) => t.genre === genre);
    if (q) list = list.filter((t) => (t.title + " " + t.artist + " " + (t.dj || "") + " " + t.genre).toLowerCase().includes(q));
    list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    res.json({ ok: true, tapes: list.map((t) => publicTape(t, req)), total: list.length });
  });

  app.get("/api/tapes/:id", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t) return res.status(404).json({ ok: false, error: "No tape with that id." });
    const user = authUser(req);
    if (!isLive(t) && !(user && user.handle === t.handle)) {
      return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    }
    res.json({ ok: true, tape: publicTape(t, req) });
  });

  function ownTape(req, res) {
    const t = store.findTape(req.params.id);
    if (!t) { res.status(404).json({ ok: false, error: "No tape with that id." }); return null; }
    if (!req.user || req.user.handle !== t.handle) {
      res.status(403).json({ ok: false, error: "That's not your tape." });
      return null;
    }
    return t;
  }

  // Owner or admin (Kris) — the admin token can act on any tape, same
  // check as the Featured slot. Used by add-tracks and back-to-draft so
  // Kris can fix a tape from the server side too.
  function ownOrAdminTape(req, res) {
    const t = store.findTape(req.params.id);
    if (!t) { res.status(404).json({ ok: false, error: "No tape with that id." }); return null; }
    const isAdmin = !!ADMIN_TOKEN && req.headers["x-admin-token"] === ADMIN_TOKEN;
    const user = authUser(req);
    if (!isAdmin && (!user || user.handle !== t.handle)) {
      res.status(403).json({ ok: false, error: "That's not your tape." });
      return null;
    }
    return t;
  }

  app.post("/api/tapes/:id/publish", requireAuth, async (req, res) => {
    const t = ownTape(req, res); if (!t) return;
    await store.mutate(() => { t.draft = false; t.releaseAt = null; if (!t.publishedAt) t.publishedAt = Date.now(); });
    res.json({ ok: true, tape: publicTape(t, req), message: "“" + t.title + "” is live in the Tapes feed now." });
  });

  app.post("/api/tapes/:id/schedule", requireAuth, async (req, res) => {
    const t = ownTape(req, res); if (!t) return;
    const ts = new Date(req.body.releaseAt || "").getTime();
    if (isNaN(ts) || ts <= Date.now()) return res.status(400).json({ ok: false, error: "Pick a premiere time in the future." });
    await store.mutate(() => { t.draft = false; t.releaseAt = ts; if (!t.publishedAt) t.publishedAt = ts; });
    res.json({ ok: true, tape: publicTape(t, req), message: "Premiere scheduled for “" + t.title + "”." });
  });

  app.post("/api/tapes/:id/draft", async (req, res) => {
    const t = ownOrAdminTape(req, res); if (!t) return;
    await store.mutate(() => { t.draft = true; t.releaseAt = null; });
    res.json({ ok: true, tape: publicTape(t, req), message: "“" + t.title + "” is back to a private draft." });
  });

  // Add tracks to an existing tape (owner or admin). Appends in upload
  // order to the end of the track list; 20 tracks max per tape.
  app.post("/api/tapes/:id/tracks", rateLimit(10, 60000), (req, res, next) => {
    // Auth BEFORE multer runs, so a rejected request writes no files.
    const t = ownOrAdminTape(req, res);
    if (!t) return;
    req.tape = t;
    req.tapeId = t.id;
    next();
  }, (req, res) => {
    upload.fields([{ name: "tracks", maxCount: MAX_TRACKS }])(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Upload failed." });
      try {
        const t = req.tape;
        const trackFiles = (req.files && req.files.tracks) || [];
        if (!trackFiles.length) return res.status(400).json({ ok: false, error: "Add at least one audio track." });
        const existing = (t.tracks || []).length;
        if (existing + trackFiles.length > MAX_TRACKS) {
          trackFiles.forEach((f) => { try { fs.unlinkSync(path.join(uploadsDir, t.id, f.filename)); } catch (e) {} });
          return res.status(400).json({ ok: false, error: "20 tracks max per tape — this tape already has " + existing + ", so you can add " + (MAX_TRACKS - existing) + " more." });
        }
        const titles = Array.isArray(req.body.trackTitles) ? req.body.trackTitles : (req.body.trackTitles ? [req.body.trackTitles] : []);
        const added = trackFiles.map((f, i) => ({
          fileName: f.originalname, stored: f.filename,
          title: String((titles[i] || f.originalname || "").trim()) || f.originalname,
        }));
        await store.mutate(() => { t.tracks.push(...added); });
        res.status(201).json({ ok: true, tape: publicTape(t, req), added: added.length, message: "Added " + added.length + " track" + (added.length === 1 ? "" : "s") + " to “" + t.title + "” — it now has " + t.tracks.length + "." });
      } catch (e) {
        console.error("add tracks failed:", e);
        res.status(500).json({ ok: false, error: "Couldn't add those tracks — try again." });
      }
    });
  });

  // Edit a tape (owner or admin). Updates any field set at upload:
  // title, artist, DJ host, genre, city, description, $cashtag,
  // cover art (new file replaces the old one; removeCover clears it),
  // and each track's title (trackTitles, in track order — a blank
  // title keeps the current one). Tracks can also be removed
  // (removeTracks: track indexes — at least one track must remain;
  // removed audio files are deleted from disk). The @handle never
  // changes here — it is the account identity. Audio files are not
  // replaced in place; remove a track and use Add tracks for a new one.
  // Accepts multipart/form-data (cover upload) or JSON.
  app.patch("/api/tapes/:id", rateLimit(10, 60000), (req, res, next) => {
    // Auth BEFORE multer runs, so a rejected request writes no files.
    const t = ownOrAdminTape(req, res);
    if (!t) return;
    req.tape = t;
    req.tapeId = t.id;
    next();
  }, (req, res) => {
    upload.fields([{ name: "cover", maxCount: 1 }])(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Upload failed." });
      try {
        const t = req.tape;
        const b = req.body || {};
        const asList = (v) => {
          if (v === undefined || v === null) return [];
          if (Array.isArray(v)) return v;
          if (typeof v === "string" && v.trim().startsWith("[")) {
            try { const p = JSON.parse(v); return Array.isArray(p) ? p : [v]; } catch (_) { return [v]; }
          }
          return String(v).split(",").map((s) => s.trim()).filter((s) => s !== "");
        };
        const has = (k) => b[k] !== undefined && b[k] !== null;
        if (has("title") && !String(b.title || "").trim()) {
          return res.status(400).json({ ok: false, error: "Add a tape title." });
        }
        if (has("artist") && !String(b.artist || "").trim()) {
          return res.status(400).json({ ok: false, error: "Add an artist name." });
        }
        if (has("genre") && !GENRES.includes(String(b.genre || "").trim())) {
          return res.status(400).json({ ok: false, error: "Pick a genre — it puts the tape on the right chart." });
        }
        const removeIdx = asList(b.removeTracks).map((v) => Number(v)).filter((n) => Number.isInteger(n) && n >= 0 && n < (t.tracks || []).length);
        const uniqueRemove = [...new Set(removeIdx)];
        if (uniqueRemove.length && (t.tracks || []).length - uniqueRemove.length < 1) {
          return res.status(400).json({ ok: false, error: "A tape needs at least one track — keep one, or delete the whole tape instead." });
        }
        const coverFile = req.files && req.files.cover && req.files.cover[0];
        const removeCover = b.removeCover === true || b.removeCover === "1" || b.removeCover === "true";
        const oldCover = t.coverFile;
        const oldTracks = uniqueRemove.map((i) => t.tracks[i]).filter(Boolean);
        const titles = asList(b.trackTitles);
        await store.mutate(() => {
          if (has("title")) t.title = String(b.title).trim();
          if (has("artist")) t.artist = String(b.artist).trim();
          if (has("dj")) t.dj = String(b.dj || "").trim();
          if (has("genre")) t.genre = String(b.genre).trim();
          if (has("city")) t.city = String(b.city || "").trim();
          if (has("desc")) t.desc = String(b.desc || "").trim();
          if (has("cashtag")) t.cashtag = normCashtag(b.cashtag);
          titles.forEach((raw, i) => {
            const v = String(raw || "").trim();
            if (i < t.tracks.length && v) t.tracks[i].title = v;
          });
          if (uniqueRemove.length) {
            t.tracks = t.tracks.filter((_, i) => !uniqueRemove.includes(i));
          }
          if (coverFile) t.coverFile = coverFile.filename;
          else if (removeCover) t.coverFile = null;
        });
        // Delete replaced / removed files from disk (after the record saved).
        if (coverFile && oldCover && oldCover !== coverFile.filename) {
          try { fs.unlinkSync(path.join(uploadsDir, t.id, oldCover)); } catch (_) {}
        } else if (removeCover && !coverFile && oldCover) {
          try { fs.unlinkSync(path.join(uploadsDir, t.id, oldCover)); } catch (_) {}
        }
        for (const tr of oldTracks) {
          if (tr.stored) { try { fs.unlinkSync(path.join(uploadsDir, t.id, tr.stored)); } catch (_) {} }
        }
        res.json({ ok: true, tape: publicTape(t, req), message: "“" + t.title + "” is updated." });
      } catch (e) {
        console.error("edit tape failed:", e);
        res.status(500).json({ ok: false, error: "Couldn't save those edits — try again." });
      }
    });
  });

  // DELETE /api/tapes/:id — owner only. Deletes the tape record, its
  // cover + audio files, and drops it from every user's saved downloads.
  // The frontend confirms before calling this — it cannot be undone.
  app.delete("/api/tapes/:id", requireAuth, async (req, res) => {
    const t = ownTape(req, res); if (!t) return;
    const tapeId = t.id;
    await store.mutate(() => { removeTapeRecord(tapeId); });
    deleteTapeFiles(tapeId);
    res.json({ ok: true });
  });

  // Featured is a paid slot ($25) — only Kris (admin token) sets it.
  app.post("/api/admin/tapes/:id/featured", async (req, res) => {
    if (!ADMIN_TOKEN || req.headers["x-admin-token"] !== ADMIN_TOKEN) {
      return res.status(403).json({ ok: false, error: "Admin token required." });
    }
    const t = store.findTape(req.params.id);
    if (!t) return res.status(404).json({ ok: false, error: "No tape with that id." });
    await store.mutate(() => { t.featured = req.body.featured !== false; });
    res.json({ ok: true, tape: publicTape(t, req) });
  });

  // Promo mailing list (Kris only, same ADMIN_TOKEN as Featured).
  // Returns ONLY the @handle + email of users who opted in to
  // promotions and gave an email — nothing else about any account.
  // No other endpoint returns emails: publicUser() never includes one.
  app.get("/api/admin/promo-emails", async (req, res) => {
    if (!ADMIN_TOKEN || req.headers["x-admin-token"] !== ADMIN_TOKEN) {
      return res.status(403).json({ ok: false, error: "Admin token required." });
    }
    const emails = Object.values(store.users)
      .filter((u) => u.promoOptIn && u.email)
      .map((u) => ({ handle: u.handle, email: u.email }))
      .sort((a, b) => a.handle.localeCompare(b.handle));
    res.json({ ok: true, count: emails.length, emails });
  });

  // ---- plays & downloads (site-wide, kept separate) ---------------------
  app.post("/api/tapes/:id/play", rateLimit(60, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    await store.mutate(() => { t.plays = (t.plays || 0) + 1; });
    res.json({ ok: true, plays: t.plays, downloads: t.downloads });
  });

  app.post("/api/tapes/:id/download", requireAuth, rateLimit(60, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const user = authUser(req);
    await store.mutate(() => {
      t.downloads = (t.downloads || 0) + 1;
      if (user && !user.downloads.includes(t.id)) user.downloads.push(t.id);
    });
    res.json({ ok: true, plays: t.plays, downloads: t.downloads });
  });

  // ---- reactions + comments (fans with accounts, everywhere the music is) ------------
  // Liking and commenting need a signed-in account: the vote is keyed
  // by the fan's @handle, so every existing account gets this with no
  // re-registration. One vote per fan per tape; changing it moves the
  // count, "none" takes it back. Counts are absolute from the server.
  // Signed-out visitors get a 401 and the site shows them the
  // create-account popup instead of voting.
  function voteKey(req) {
    const user = authUser(req);
    if (!user) return null;
    return "h:" + user.handle;
  }
  app.post("/api/tapes/:id/react", rateLimit(60, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const vote = String((req.body && req.body.vote) || "").trim();
    if (vote !== "up" && vote !== "down" && vote !== "none") {
      return res.status(400).json({ ok: false, error: "Vote 'up', 'down', or 'none'." });
    }
    const key = voteKey(req);
    if (!key) return res.status(401).json({ ok: false, error: "Sign in to like this tape." });
    const out = await store.mutate(() => {
      if (!t.votes) t.votes = { up: 0, down: 0 };
      if (!t.voteBy) t.voteBy = {};
      const prev = t.voteBy[key] || "none";
      if (prev === vote) return { up: t.votes.up || 0, down: t.votes.down || 0, myVote: prev };
      if (prev === "up") t.votes.up = Math.max(0, (t.votes.up || 0) - 1);
      if (prev === "down") t.votes.down = Math.max(0, (t.votes.down || 0) - 1);
      if (vote === "up") t.votes.up = (t.votes.up || 0) + 1;
      if (vote === "down") t.votes.down = (t.votes.down || 0) + 1;
      if (vote === "none") delete t.voteBy[key]; else t.voteBy[key] = vote;
      return { up: t.votes.up || 0, down: t.votes.down || 0, myVote: vote };
    });
    res.json({ ok: true, up: out.up, down: out.down, myVote: out.myVote });
  });

  // Comments: newest first. The author is always the signed-in fan's
  // @handle. Text is capped at 500 characters and the tape keeps the
  // newest 500 comments. Signed-out visitors get a 401 and the site
  // shows them the create-account popup instead of posting.
  app.get("/api/tapes/:id/comments", (req, res) => {
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const list = (t.comments || []).slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    res.json({ ok: true, comments: list.map((c) => ({ ...c, mentions: mentionsMap(c.text || "") })) });
  });

  app.post("/api/tapes/:id/comments", rateLimit(10, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const user = authUser(req);
    if (!user) return res.status(401).json({ ok: false, error: "Sign in to comment." });
    const text = String((req.body && req.body.text) || "").trim();
    if (!text || text.length > 500) {
      return res.status(400).json({ ok: false, error: "Write a comment between 1 and 500 characters." });
    }
    const comment = { id: crypto.randomBytes(8).toString("hex"), name: user.handle, text, createdAt: Date.now() };
    await store.mutate(() => {
      if (!t.comments) t.comments = [];
      t.comments.push(comment);
      if (t.comments.length > 500) t.comments = t.comments.slice(-500);
      notifyMentions(text, user, { url: "/tape/" + t.id, label: "mentioned you on “" + t.title + "”" });
    });
    res.status(201).json({ ok: true, comment: { ...comment, mentions: mentionsMap(text) } });
  });

  // ---- My Library: playlists -------------------------------------------
  // Server-side, per account, so a playlist made on one phone is there
  // after signing in anywhere else ("login anywhere"). Saving to a
  // library or a playlist needs a signed-in account — same rule as
  // liking and commenting. Guests can still stream everything for
  // free; downloads need a signed-in account — a signed-out download
  // tap shows the create-account popup instead. Every response carries
  // the absolute playlist state, never a delta, and items resolve to
  // tape + track titles so the client can render without extra lookups.
  const MAX_PLAYLISTS = 20;
  const MAX_PLAYLIST_NAME = 60;
  function playlistId() {
    return "p_" + Date.now().toString(36) + "_" + crypto.randomBytes(4).toString("hex");
  }
  function userPlaylists(u) {
    if (!Array.isArray(u.playlists)) u.playlists = [];
    return u.playlists;
  }
  function findPlaylist(u, id) {
    return userPlaylists(u).find((p) => p.id === id) || null;
  }
  function publicPlaylist(pl) {
    return {
      id: pl.id, name: pl.name, createdAt: pl.createdAt,
      items: (pl.items || []).map((it) => {
        const t = store.findTape(it.tapeId);
        if (!t || !t.tracks || !t.tracks[it.trackIdx]) return null;
        return {
          tapeId: it.tapeId, trackIdx: it.trackIdx,
          tapeTitle: t.title, artist: t.artist, handle: t.handle,
          trackTitle: t.tracks[it.trackIdx].title,
        };
      }).filter(Boolean),
    };
  }

  app.get("/api/playlists", requireAuth, (req, res) => {
    res.json({ ok: true, playlists: userPlaylists(req.user).map(publicPlaylist) });
  });

  app.post("/api/playlists", requireAuth, rateLimit(30, 60000), async (req, res) => {
    const name = String((req.body && req.body.name) || "").trim();
    if (!name || name.length > MAX_PLAYLIST_NAME) {
      return res.status(400).json({ ok: false, error: "Give the playlist a name (up to 60 characters)." });
    }
    const pls = userPlaylists(req.user);
    if (pls.length >= MAX_PLAYLISTS) {
      return res.status(400).json({ ok: false, error: "You have 20 playlists already — delete one to make room." });
    }
    const pl = { id: playlistId(), name, items: [], createdAt: Date.now() };
    await store.mutate(() => { pls.push(pl); });
    res.status(201).json({ ok: true, playlist: publicPlaylist(pl) });
  });

  app.patch("/api/playlists/:id", requireAuth, rateLimit(30, 60000), async (req, res) => {
    const pl = findPlaylist(req.user, req.params.id);
    if (!pl) return res.status(404).json({ ok: false, error: "No playlist with that id." });
    const name = String((req.body && req.body.name) || "").trim();
    if (!name || name.length > MAX_PLAYLIST_NAME) {
      return res.status(400).json({ ok: false, error: "Give the playlist a name (up to 60 characters)." });
    }
    await store.mutate(() => { pl.name = name; });
    res.json({ ok: true, playlist: publicPlaylist(pl) });
  });

  app.delete("/api/playlists/:id", requireAuth, rateLimit(30, 60000), async (req, res) => {
    const pls = userPlaylists(req.user);
    const i = pls.findIndex((p) => p.id === req.params.id);
    if (i < 0) return res.status(404).json({ ok: false, error: "No playlist with that id." });
    await store.mutate(() => { pls.splice(i, 1); });
    res.json({ ok: true });
  });

  app.post("/api/playlists/:id/items", requireAuth, rateLimit(60, 60000), async (req, res) => {
    const pl = findPlaylist(req.user, req.params.id);
    if (!pl) return res.status(404).json({ ok: false, error: "No playlist with that id." });
    const tapeId = String((req.body && req.body.tapeId) || "");
    const t = store.findTape(tapeId);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const rawIdx = req.body && req.body.trackIdx;
    // No trackIdx means the whole tape, in album order.
    const idxs = (rawIdx === undefined || rawIdx === null || rawIdx === "")
      ? (t.tracks || []).map((_, i) => i)
      : [Number(rawIdx)];
    if (idxs.some((i) => !Number.isInteger(i) || i < 0 || i >= (t.tracks || []).length)) {
      return res.status(400).json({ ok: false, error: "That track isn't on this tape." });
    }
    let added = 0;
    await store.mutate(() => {
      if (!Array.isArray(pl.items)) pl.items = [];
      for (const i of idxs) {
        if (!pl.items.some((it) => it.tapeId === tapeId && it.trackIdx === i)) {
          pl.items.push({ tapeId, trackIdx: i });
          added++;
        }
      }
    });
    res.json({ ok: true, added, playlist: publicPlaylist(pl) });
  });

  app.delete("/api/playlists/:id/items/:index", requireAuth, rateLimit(60, 60000), async (req, res) => {
    const pl = findPlaylist(req.user, req.params.id);
    if (!pl) return res.status(404).json({ ok: false, error: "No playlist with that id." });
    const idx = Number(req.params.index);
    if (!Number.isInteger(idx) || idx < 0 || idx >= (pl.items || []).length) {
      return res.status(400).json({ ok: false, error: "No song at that spot in the playlist." });
    }
    await store.mutate(() => { pl.items.splice(idx, 1); });
    res.json({ ok: true, playlist: publicPlaylist(pl) });
  });

  app.post("/api/playlists/:id/move", requireAuth, rateLimit(60, 60000), async (req, res) => {
    const pl = findPlaylist(req.user, req.params.id);
    if (!pl) return res.status(404).json({ ok: false, error: "No playlist with that id." });
    const from = Number(req.body && req.body.from);
    const to = Number(req.body && req.body.to);
    const items = pl.items || [];
    if (!Number.isInteger(from) || !Number.isInteger(to) || from < 0 || from >= items.length || to < 0 || to >= items.length) {
      return res.status(400).json({ ok: false, error: "Move it to a spot inside the playlist." });
    }
    await store.mutate(() => {
      const it = items.splice(from, 1)[0];
      items.splice(to, 0, it);
    });
    res.json({ ok: true, playlist: publicPlaylist(pl) });
  });

  // ---- @mentions + notifications --------------------------------------
  // Mentions: @handle in any submitted text resolves to the user record.
  // The tag renders as that person's display name (a link to their
  // profile) — never the bare @handle. Every mention also alerts the
  // mentioned user, anywhere on the site: tape comments, wall posts and
  // comments, Trenches posts and comments, share captions.
  function mentionedHandles(text) {
    const out = [];
    const seen = {};
    String(text || "").replace(/@([A-Za-z0-9_]{2,30})/g, function (m, h) {
      const handle = normHandle(h);
      if (!seen[handle]) { seen[handle] = 1; out.push(handle); }
      return m;
    });
    return out;
  }
  // { "@handle": "Display Name" } for every mentioned handle that is a
  // real account — the frontend renders the name as the link text.
  function mentionsMap(text) {
    const map = {};
    for (const h of mentionedHandles(text)) {
      const u = store.users[h];
      if (u) map[h] = u.name || h.slice(1);
    }
    return map;
  }
  // Create one notification per mentioned fan (never for yourself).
  // Call inside a store.mutate so the write persists with the post or
  // comment. context is { url, label } — where the mention happened,
  // so the bell can take the tagged fan straight there.
  function notifyMentions(text, fromUser, context) {
    const targets = mentionedHandles(text).filter((h) => h !== fromUser.handle && store.users[h]);
    if (!targets.length) return;
    const snippet = String(text || "").trim().slice(0, 80);
    for (const h of targets) {
      store.notifications.unshift({
        id: "n_" + Date.now().toString(36) + "_" + crypto.randomBytes(6).toString("hex"),
        to: h, from: fromUser.handle, fromName: fromUser.name, kind: "mention",
        url: context.url, label: context.label, snippet,
        createdAt: Date.now(), read: false,
      });
      // Cap the inbox: newest 100 per fan.
      const mine = store.notifications.filter((n) => n.to === h);
      if (mine.length > 100) {
        const keep = new Set(mine.slice(0, 100).map((n) => n.id));
        store.notifications = store.notifications.filter((n) => n.to !== h || keep.has(n.id));
      }
    }
  }
  // ---- fan walls + follow ------------------------------------------------
  // A wall is private when the profile owner set it so. The wall is
  // visible only to the owner and their followers — enforced here, on
  // the server, on every read and write, not just in the UI.
  function followersOf(u) { return Array.isArray(u.followers) ? u.followers : []; }
  function followingOf(u) { return Array.isArray(u.following) ? u.following : []; }
  function canSeeWall(viewer, owner) {
    if (!owner) return false;
    if (!owner.isPrivate) return true;
    if (!viewer) return false;
    if (viewer.handle === owner.handle) return true;
    return followersOf(owner).indexOf(viewer.handle) >= 0;
  }
  function canSeeWallPost(req, post) {
    if (!post || !post.wall) return true;
    return canSeeWall(authUser(req), store.users[post.wall]);
  }

  // ---- Trenches: the social feed -----------------------------------------
  // Fans with accounts post pictures and videos; every post gets the
  // same options as the music pages, in the same order: thumbs up,
  // thumbs down, comments, share. Posting, liking, and commenting
  // need an account; share stays open. Posts are separate from tapes —
  // they never show in the Tapes feed, Rankings, or Singles.
  // Media lives under uploads/feed/<postId>/, one file per post:
  // photos cap at 10 MB (same as cover art), videos at 100 MB.
  function postId() {
    return "f_" + Date.now().toString(36) + "_" + crypto.randomBytes(6).toString("hex");
  }
  // Resolve a post for the client: voteBy never leaves the server, and
  // a shared tape / shared post resolves to its own public form, one
  // level deep (a share of a share shows the original).
  function publicPost(p, req, shallow) {
    const base = (req ? req.protocol + "://" + req.get("host") : "");
    const owner = store.users[p.author];
    const authorAvatar = owner && owner.avatarFile && base ? base + "/api/media/avatars/" + p.author.slice(1) : "";
    const out = {
      id: p.id, author: p.author, authorAvatar,
      kind: p.kind, text: p.text || "",
      wall: p.wall || null,
      mentions: mentionsMap(p.text || ""),
      mediaUrl: p.mediaFile && base ? base + "/api/media/feed/" + p.id : null,
      mediaType: p.mediaType || null,
      up: (p.votes && p.votes.up) || 0, down: (p.votes && p.votes.down) || 0,
      commentCount: (p.comments || []).length,
      createdAt: p.createdAt,
    };
    if (p.tapeId) {
      const t = store.findTape(p.tapeId);
      out.tape = t ? { id: t.id, title: t.title, artist: t.artist, handle: t.handle, cover: t.coverFile && base ? base + "/api/media/" + t.id + "/cover" : null } : null;
    }
    if (p.sharedPostId && !shallow) {
      const s = store.findPost(p.sharedPostId);
      out.sharedPost = s ? publicPost(s, req, true) : null;
    }
    return out;
  }

  const feedStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(uploadsDir, "feed", req.feedPostId);
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      cb(null, "media" + path.extname(file.originalname || "").toLowerCase());
    },
  });
  const feedUpload = multer({
    storage: feedStorage,
    limits: { fileSize: MAX_FEED_VIDEO_BYTES, files: 1 },
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname || "").toLowerCase();
      if (IMAGE_EXTS[ext] || VIDEO_EXTS[ext]) return cb(null, true);
      return cb(new Error("Feed media must be a photo (JPG, PNG, WebP, GIF) or a video (MP4, MOV, WebM, M4V)."));
    },
  });

  // Newest first. Public — guests can read the feed, they just can't post.
  // Wall posts never show here: they live on their owner's profile wall.
  app.get("/api/feed", (req, res) => {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 50, 1), 100);
    const list = store.posts.filter((p) => !p.wall).slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, limit);
    res.json({ ok: true, posts: list.map((p) => publicPost(p, req)) });
  });

  // Shared by POST /api/feed (Trenches) and POST /api/artists/:handle/wall:
  // text and/or one photo/video, same caps, same 500-character limit.
  // wallHandle is null for Trenches, the profile @handle for a wall post.
  // Every @mention in the text alerts the mentioned fan.
  function savePostFromRequest(req, res, wallHandle) {
    feedUpload.single("media")(req, res, async (err) => {
      if (err) return res.status(400).json({ ok: false, error: err.message || "Upload failed." });
      const text = String((req.body && req.body.text) || "").trim();
      if (text.length > 500) return res.status(400).json({ ok: false, error: "Keep it to 500 characters or less." });
      const f = req.file || null;
      if (!text && !f) return res.status(400).json({ ok: false, error: "Write something or add a photo or video." });
      if (f) {
        const ext = path.extname(f.originalname || "").toLowerCase();
        const isImage = !!IMAGE_EXTS[ext];
        const cap = isImage ? MAX_FEED_IMAGE_BYTES : MAX_FEED_VIDEO_BYTES;
        if (f.size > cap) {
          try { fs.unlinkSync(f.path); } catch (_) {}
          return res.status(400).json({ ok: false, error: isImage ? "That photo is over 10 MB — pick a smaller one." : "That video is over 100 MB — trim it down first." });
        }
      }
      const post = {
        id: req.feedPostId, author: req.user.handle, kind: "text",
        text, mediaFile: f ? f.filename : null,
        mediaType: f ? (IMAGE_EXTS[path.extname(f.originalname || "").toLowerCase()] ? "image" : "video") : null,
        tapeId: null, sharedPostId: null, wall: wallHandle || null,
        votes: { up: 0, down: 0 }, voteBy: {}, comments: [],
        createdAt: Date.now(),
      };
      const notifyCtx = wallHandle
        ? { url: "/artist/" + wallHandle.slice(1), label: "mentioned you on " + wallHandle + "'s wall" }
        : { url: "/trenches#" + post.id, label: "mentioned you in Trenches" };
      await store.mutate(() => {
        store.posts.unshift(post);
        notifyMentions(text, req.user, notifyCtx);
      });
      res.status(201).json({ ok: true, post: publicPost(post, req) });
    });
  }

  // Post to Trenches: text, a photo/video, or both. Accepts JSON
  // ({text}) or multipart (text + one "media" file).
  app.post("/api/feed", requireAuth, rateLimit(10, 60000), (req, res, next) => {
    req.feedPostId = postId();
    next();
  }, (req, res) => savePostFromRequest(req, res, null));

  // Share to Trenches: a tape or a post, with an optional caption
  // (the caption shows above the shared tape/post). Sharing is
  // posting, so it needs a signed-in account.
  app.post("/api/feed/share", requireAuth, rateLimit(10, 60000), async (req, res) => {
    const tapeId = String((req.body && req.body.tapeId) || "");
    const sharedId = String((req.body && req.body.postId) || "");
    const caption = String((req.body && req.body.caption) || "").trim();
    if (caption.length > 500) return res.status(400).json({ ok: false, error: "Keep the caption to 500 characters or less." });
    if ((tapeId && sharedId) || (!tapeId && !sharedId)) {
      return res.status(400).json({ ok: false, error: "Share one thing: a tape or a post." });
    }
    let kind, tape = null, shared = null;
    if (tapeId) {
      tape = store.findTape(tapeId);
      if (!tape || !isLive(tape)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
      kind = "tape";
    } else {
      shared = store.findPost(sharedId);
      if (!shared) return res.status(404).json({ ok: false, error: "That post isn't here anymore." });
      // A post on a private wall stays private — it can't be shared out.
      if (shared.wall && !canSeeWallPost(req, shared)) return res.status(404).json({ ok: false, error: "That post isn't here anymore." });
      kind = "post";
    }
    const post = {
      id: postId(), author: req.user.handle, kind,
      text: caption, mediaFile: null, mediaType: null,
      tapeId: tape ? tape.id : null, sharedPostId: shared ? shared.id : null,
      votes: { up: 0, down: 0 }, voteBy: {}, comments: [],
      createdAt: Date.now(),
    };
    await store.mutate(() => {
      store.posts.unshift(post);
      notifyMentions(caption, req.user, { url: "/trenches#" + post.id, label: "mentioned you in Trenches" });
    });
    res.status(201).json({ ok: true, post: publicPost(post, req) });
  });

  // Post reactions: same rules as tapes — one vote per fan, absolute counts.
  app.post("/api/feed/:id/react", rateLimit(60, 60000), async (req, res) => {
    const p = store.findPost(req.params.id);
    if (!p) return res.status(404).json({ ok: false, error: "That post isn't here anymore." });
    if (p.wall && !canSeeWallPost(req, p)) return res.status(403).json({ ok: false, private: true, error: "This profile is private." });
    const vote = String((req.body && req.body.vote) || "").trim();
    if (vote !== "up" && vote !== "down" && vote !== "none") {
      return res.status(400).json({ ok: false, error: "Vote 'up', 'down', or 'none'." });
    }
    const user = authUser(req);
    if (!user) return res.status(401).json({ ok: false, error: "Sign in to like this post." });
    const key = "h:" + user.handle;
    const out = await store.mutate(() => {
      if (!p.votes) p.votes = { up: 0, down: 0 };
      if (!p.voteBy) p.voteBy = {};
      const prev = p.voteBy[key] || "none";
      if (prev === vote) return { up: p.votes.up || 0, down: p.votes.down || 0, myVote: prev };
      if (prev === "up") p.votes.up = Math.max(0, (p.votes.up || 0) - 1);
      if (prev === "down") p.votes.down = Math.max(0, (p.votes.down || 0) - 1);
      if (vote === "up") p.votes.up = (p.votes.up || 0) + 1;
      if (vote === "down") p.votes.down = (p.votes.down || 0) + 1;
      if (vote === "none") delete p.voteBy[key]; else p.voteBy[key] = vote;
      return { up: p.votes.up || 0, down: p.votes.down || 0, myVote: vote };
    });
    res.json({ ok: true, up: out.up, down: out.down, myVote: out.myVote });
  });

  // Post comments: newest first, author is always the signed-in fan's @handle.
  app.get("/api/feed/:id/comments", (req, res) => {
    const p = store.findPost(req.params.id);
    if (!p) return res.status(404).json({ ok: false, error: "That post isn't here anymore." });
    if (p.wall && !canSeeWallPost(req, p)) return res.status(403).json({ ok: false, private: true, error: "This profile is private." });
    const list = (p.comments || []).slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    res.json({ ok: true, comments: list.map((c) => ({ ...c, mentions: mentionsMap(c.text || "") })) });
  });

  app.post("/api/feed/:id/comments", rateLimit(10, 60000), async (req, res) => {
    const p = store.findPost(req.params.id);
    if (!p) return res.status(404).json({ ok: false, error: "That post isn't here anymore." });
    if (p.wall && !canSeeWallPost(req, p)) return res.status(403).json({ ok: false, private: true, error: "This profile is private." });
    const user = authUser(req);
    if (!user) return res.status(401).json({ ok: false, error: "Sign in to comment." });
    const text = String((req.body && req.body.text) || "").trim();
    if (!text || text.length > 500) {
      return res.status(400).json({ ok: false, error: "Write a comment between 1 and 500 characters." });
    }
    const comment = { id: crypto.randomBytes(8).toString("hex"), name: user.handle, text, createdAt: Date.now() };
    const notifyCtx = p.wall
      ? { url: "/artist/" + p.wall.slice(1), label: "mentioned you on " + p.wall + "'s wall" }
      : { url: "/trenches#" + p.id, label: "mentioned you in Trenches" };
    await store.mutate(() => {
      if (!p.comments) p.comments = [];
      p.comments.push(comment);
      if (p.comments.length > 500) p.comments = p.comments.slice(-500);
      notifyMentions(text, user, notifyCtx);
    });
    res.status(201).json({ ok: true, comment: { ...comment, mentions: mentionsMap(text) } });
  });

  // ---- fan profile walls + follow + notifications -----------------------
  // A wall is the Trenches pattern scoped to one profile: newest first,
  // text and/or a photo/video, thumbs up/down, comments, share — same
  // post record, with wall = the profile owner's @handle. Private
  // profiles show their wall only to the owner and their followers.
  app.get("/api/artists/:handle/wall", (req, res) => {
    const handle = normHandle(req.params.handle);
    const owner = store.users[handle];
    if (!owner) return res.status(404).json({ ok: false, error: "No profile for " + handle + " yet." });
    const viewer = authUser(req);
    if (!canSeeWall(viewer, owner)) return res.status(403).json({ ok: false, private: true, error: "This profile is private — follow " + handle + " to see their wall." });
    const list = store.posts.filter((p) => p.wall === handle).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    res.json({
      ok: true, isPrivate: !!owner.isPrivate,
      isOwner: !!(viewer && viewer.handle === handle),
      isFollowing: !!(viewer && followersOf(owner).indexOf(viewer.handle) >= 0),
      followers: followersOf(owner).length, following: followingOf(owner).length,
      posts: list.map((p) => publicPost(p, req)),
    });
  });

  app.post("/api/artists/:handle/wall", requireAuth, rateLimit(10, 60000), (req, res, next) => {
    const handle = normHandle(req.params.handle);
    const owner = store.users[handle];
    if (!owner) return res.status(404).json({ ok: false, error: "No profile for " + handle + " yet." });
    if (!canSeeWall(req.user, owner)) return res.status(403).json({ ok: false, private: true, error: "This profile is private — follow " + handle + " to post on their wall." });
    req.feedPostId = postId();
    req.wallHandle = handle;
    next();
  }, (req, res) => savePostFromRequest(req, res, req.wallHandle));

  // Follow / unfollow: idempotent, counts come back absolute.
  app.post("/api/artists/:handle/follow", requireAuth, rateLimit(30, 60000), async (req, res) => {
    const handle = normHandle(req.params.handle);
    const target = store.users[handle];
    if (!target) return res.status(404).json({ ok: false, error: "No profile for " + handle + " yet." });
    if (handle === req.user.handle) return res.status(400).json({ ok: false, error: "You can't follow yourself." });
    const out = await store.mutate(() => {
      if (!Array.isArray(target.followers)) target.followers = [];
      if (!Array.isArray(req.user.following)) req.user.following = [];
      if (target.followers.indexOf(req.user.handle) < 0) target.followers.push(req.user.handle);
      if (req.user.following.indexOf(handle) < 0) req.user.following.push(handle);
      return { followers: target.followers.length, following: followingOf(target).length };
    });
    res.json({ ok: true, following: true, followers: out.followers, followingCount: out.following });
  });
  app.post("/api/artists/:handle/unfollow", requireAuth, rateLimit(30, 60000), async (req, res) => {
    const handle = normHandle(req.params.handle);
    const target = store.users[handle];
    if (!target) return res.status(404).json({ ok: false, error: "No profile for " + handle + " yet." });
    if (handle === req.user.handle) return res.status(400).json({ ok: false, error: "You can't unfollow yourself." });
    const out = await store.mutate(() => {
      if (Array.isArray(target.followers)) target.followers = target.followers.filter((h) => h !== req.user.handle);
      if (Array.isArray(req.user.following)) req.user.following = req.user.following.filter((h) => h !== handle);
      return { followers: followersOf(target).length, following: followingOf(target).length };
    });
    res.json({ ok: true, following: false, followers: out.followers, followingCount: out.following });
  });

  // Search fans by name or @handle — so fans with no tapes are findable
  // in the header search, not just artists with live tapes. Private
  // profiles are listed (their existence is public); only their wall
  // is gated. No query → no results.
  app.get("/api/artists", (req, res) => {
    const q = String(req.query.search || "").trim().toLowerCase();
    if (req.query.list === "fans") {
      // Fans directory: every fan account, newest first — so fans can be
      // found and followed without already knowing a name or @handle.
      const out = Object.values(store.users)
        .filter((u) => u.type === "fan")
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
        .slice(0, 100)
        .map((u) => publicUser(u, apiBase(req)));
      return res.json({ ok: true, artists: out });
    }
    if (!q) return res.json({ ok: true, artists: [] });
    const out = Object.values(store.users)
      .filter((u) => (u.name || "").toLowerCase().indexOf(q) >= 0 || u.handle.toLowerCase().indexOf(q) >= 0 || u.handle.slice(1).toLowerCase().indexOf(q) >= 0)
      .slice(0, 6)
      .map((u) => publicUser(u, apiBase(req)));
    res.json({ ok: true, artists: out });
  });

  // Notifications: @mention alerts. GET lists the signed-in fan's,
  // newest first, with the unread count. POST /read marks one (by id)
  // or all (no id) as read.
  app.get("/api/notifications", requireAuth, (req, res) => {
    const mine = store.notifications.filter((n) => n.to === req.user.handle).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 100);
    res.json({ ok: true, unread: mine.filter((n) => !n.read).length, notifications: mine });
  });
  app.post("/api/notifications/read", requireAuth, async (req, res) => {
    const id = String((req.body && req.body.id) || "");
    await store.mutate(() => {
      for (const n of store.notifications) {
        if (n.to !== req.user.handle) continue;
        if (!id || n.id === id) n.read = true;
      }
    });
    const unread = store.notifications.filter((n) => n.to === req.user.handle && !n.read).length;
    res.json({ ok: true, unread });
  });

  // GET /api/tapes/:id/download-all — the whole tape as one ZIP file.
  // One click, one file. The download itself is counted by the POST
  // /download the button fires first, so this endpoint only streams.
  // Live tapes only, and only for signed-in accounts (token via the
  // Authorization header or ?token=, since the button opens it as a
  // plain link). Each song is "01 - Title.mp3" in album order,
  // plus the cover art when the tape has one.
  app.get("/api/tapes/:id/download-all", requireAuthOrQuery, rateLimit(10, 60000), async (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const t = store.findTape(req.params.id);
    if (!t || !isLive(t)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    const tracks = t.tracks || [];
    if (!tracks.length) return res.status(404).json({ ok: false, error: "That tape has no songs yet." });
    const clean = (s) => String(s || "").replace(/[\\/:*?"<>|\x00-\x1f]/g, "").trim();
    const entries = [];
    for (let i = 0; i < tracks.length; i++) {
      const p = tapeFilePath(t, "track", i);
      if (!p || !fs.existsSync(p.file)) return res.status(500).json({ ok: false, error: "A song file is missing — the tape can't be zipped right now." });
      const ext = path.extname(p.name || tracks[i].stored || ".mp3") || ".mp3";
      const title = clean(tracks[i].title) || ("Track " + (i + 1));
      entries.push({ file: p.file, name: String(i + 1).padStart(2, "0") + " - " + title + ext });
    }
    const cover = tapeFilePath(t, "cover", 0);
    if (cover && fs.existsSync(cover.file)) entries.push({ file: cover.file, name: "cover" + (path.extname(cover.name || "") || ".jpg") });
    const zipName = clean(t.title) || "mixtape";
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="' + zipName + '.zip"');
    const archive = new ZipArchive({ zlib: { level: 6 } });
    archive.on("error", () => { try { res.destroy(); } catch (_) {} });
    archive.pipe(res);
    entries.forEach((e) => archive.file(e.file, { name: e.name }));
    await archive.finalize();
  });

  // ---- media: stream / download the actual files ------------------------
  // GET /api/media/:tapeId/cover — cover art.
  // GET /api/media/:tapeId/track/:idx — audio, with HTTP Range support so
  // the player can seek. Streaming stays free for everyone; ?download=1
  // sends it as an attachment (the Android DownloadManager path and the
  // web download button) and needs a signed-in account (token via the
  // Authorization header or ?token=, since downloads open as plain links).
  function tapeFilePath(t, kind, idx) {
    if (!t) return null;
    if (kind === "cover") {
      if (!t.coverFile) return null;
      return { file: path.join(uploadsDir, t.id, t.coverFile), mime: IMAGE_EXTS[path.extname(t.coverFile).toLowerCase()] || "image/jpeg", name: t.coverFile };
    }
    const tr = (t.tracks || [])[idx];
    if (!tr) return null;
    return { file: path.join(uploadsDir, t.id, tr.stored), mime: AUDIO_EXTS[path.extname(tr.stored).toLowerCase()] || "audio/mpeg", name: tr.fileName };
  }
  function serveFile(req, res, t, kind, idx) {
    const target = tapeFilePath(t, kind, idx);
    if (!target) return res.status(404).json({ ok: false, error: "File not found." });
    const resolved = path.resolve(target.file);
    if (!resolved.startsWith(path.resolve(uploadsDir) + path.sep)) {
      return res.status(400).json({ ok: false, error: "Bad file path." });
    }
    fs.stat(resolved, (err, stat) => {
      if (err || !stat.isFile()) return res.status(404).json({ ok: false, error: "File not found." });
      const download = req.query.download === "1";
      const range = req.headers.range;
      if (range && !download) {
        const m = /^bytes=(\d*)-(\d*)$/.exec(range);
        if (m) {
          const start = m[1] ? parseInt(m[1], 10) : 0;
          const end = m[2] ? Math.min(parseInt(m[2], 10), stat.size - 1) : stat.size - 1;
          if (isNaN(start) || isNaN(end) || start > end || start >= stat.size) {
            res.status(416).setHeader("Content-Range", "bytes */" + stat.size).end();
            return;
          }
          res.status(206);
          res.setHeader("Content-Range", "bytes " + start + "-" + end + "/" + stat.size);
          res.setHeader("Accept-Ranges", "bytes");
          res.setHeader("Content-Length", end - start + 1);
          res.setHeader("Content-Type", target.mime);
          fs.createReadStream(resolved, { start, end }).pipe(res);
          return;
        }
      }
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", target.mime);
      res.setHeader("Accept-Ranges", "bytes");
      if (download) res.setHeader("Content-Disposition", 'attachment; filename="' + String(target.name).replace(/["\r\n]/g, "") + '"');
      fs.createReadStream(resolved).pipe(res);
    });
  }
  app.get("/api/media/:tapeId/cover", (req, res) => {
    const t = store.findTape(req.params.tapeId);
    if (!t) return res.status(404).json({ ok: false, error: "No tape with that id." });
    const user = authUser(req);
    if (!isLive(t) && !(user && user.handle === t.handle)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    serveFile(req, res, t, "cover", 0);
  });
  app.get("/api/media/:tapeId/track/:idx", (req, res) => {
    const idx = parseInt(req.params.idx, 10);
    if (isNaN(idx) || idx < 0) return res.status(400).json({ ok: false, error: "Bad track number." });
    const t = store.findTape(req.params.tapeId);
    if (!t) return res.status(404).json({ ok: false, error: "No tape with that id." });
    const user = authUser(req);
    if (!isLive(t) && !(user && user.handle === t.handle)) return res.status(404).json({ ok: false, error: "That tape isn't live yet." });
    if (req.query.download === "1" && !authUserOrQuery(req)) return res.status(401).json({ ok: false, error: "Sign in first to download — your @handle and password work on any device." });
    serveFile(req, res, t, "track", idx);
  });

  // Public profile photo, by @handle (the @ is optional in the URL).
  app.get("/api/media/avatars/:handle", (req, res) => {
    const handle = normHandle(req.params.handle);
    const u = store.users[handle];
    if (!u || !u.avatarFile) return res.status(404).json({ ok: false, error: "No photo for that profile." });
    const file = path.join(uploadsDir, "avatars", handle.slice(1), u.avatarFile);
    const resolved = path.resolve(file);
    if (!resolved.startsWith(path.resolve(uploadsDir) + path.sep)) return res.status(400).json({ ok: false, error: "Bad file path." });
    fs.stat(resolved, (err, stat) => {
      if (err || !stat.isFile()) return res.status(404).json({ ok: false, error: "File not found." });
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", IMAGE_EXTS[path.extname(u.avatarFile).toLowerCase()] || "image/jpeg");
      fs.createReadStream(resolved).pipe(res);
    });
  });

  // Trenches media: one photo or video per post, served by post id.
  // A post on a private wall stays private — its media too.
  app.get("/api/media/feed/:id", (req, res) => {
    const p = store.findPost(req.params.id);
    if (!p || !p.mediaFile) return res.status(404).json({ ok: false, error: "No media on that post." });
    if (p.wall && !canSeeWallPost(req, p)) return res.status(403).json({ ok: false, private: true, error: "This profile is private." });
    const file = path.join(uploadsDir, "feed", p.id, p.mediaFile);
    const resolved = path.resolve(file);
    if (!resolved.startsWith(path.resolve(uploadsDir) + path.sep)) return res.status(400).json({ ok: false, error: "Bad file path." });
    fs.stat(resolved, (err, stat) => {
      if (err || !stat.isFile()) return res.status(404).json({ ok: false, error: "File not found." });
      const ext = path.extname(p.mediaFile).toLowerCase();
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", IMAGE_EXTS[ext] || VIDEO_EXTS[ext] || "application/octet-stream");
      res.setHeader("Accept-Ranges", "bytes");
      fs.createReadStream(resolved).pipe(res);
    });
  });

  // ---- featured + artist of the week ------------------------------------
  app.get("/api/featured", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const live = store.tapes.filter(isLive);
    const featured = live.filter((t) => t.featured).map((t) => publicTape(t, req));
    const sorted = live.slice().sort((a, b) => ((b.plays || 0) + (b.downloads || 0)) - ((a.plays || 0) + (a.downloads || 0)));
    const aotw = sorted.length ? publicTape(sorted[0], req) : null;
    const soon = store.tapes.filter(isScheduled).sort((a, b) => a.releaseAt - b.releaseAt).map((t) => publicTape(t, req));
    res.json({ ok: true, featured, artistOfTheWeek: aotw, comingSoon: soon });
  });

  // ---- rankings -----------------------------------------------------------
  // mode: global (plays+downloads) | local (city, plays+downloads) |
  // plays | downloads | genre (genre filter, plays+downloads).
  app.get("/api/rankings", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const mode = String(req.query.mode || "global");
    const city = String(req.query.city || "").trim().toLowerCase();
    const genre = String(req.query.genre || "");
    let live = store.tapes.filter(isLive);
    let metric, label;
    if (mode === "plays") { metric = (t) => t.plays || 0; label = "plays"; }
    else if (mode === "downloads") { metric = (t) => t.downloads || 0; label = "downloads"; }
    else if (mode === "local") {
      live = live.filter((t) => (t.city || "").toLowerCase() === city);
      metric = (t) => (t.plays || 0) + (t.downloads || 0); label = "plays + downloads";
    } else if (mode === "genre") {
      live = live.filter((t) => t.genre === genre);
      metric = (t) => (t.plays || 0) + (t.downloads || 0); label = "plays + downloads";
    } else { metric = (t) => (t.plays || 0) + (t.downloads || 0); label = "plays + downloads"; }
    live.sort((a, b) => metric(b) - metric(a));
    res.json({ ok: true, mode, label, tapes: live.map((t) => publicTape(t, req)) });
  });

  // ---- year-end stats -----------------------------------------------------
  // Five boards, plays and downloads ALWAYS separate. Most Mixtapes counts
  // published tapes only — drafts never count. Year = the year a tape was
  // published (publishedAt, falling back to createdAt).
  app.get("/api/stats/year/:year", (req, res) => {
    const year = parseInt(req.params.year, 10);
    if (isNaN(year) || year < 2020 || year > 2100) return res.status(400).json({ ok: false, error: "Bad year." });
    const published = store.tapes.filter((t) => {
      if (t.draft) return false;
      const d = new Date(t.publishedAt || t.createdAt || 0);
      return d.getFullYear() === year;
    });
    const totalPlays = published.reduce((s, t) => s + (t.plays || 0), 0);
    const totalDownloads = published.reduce((s, t) => s + (t.downloads || 0), 0);
    const byPlays = published.slice().sort((a, b) => (b.plays || 0) - (a.plays || 0));
    const byDownloads = published.slice().sort((a, b) => (b.downloads || 0) - (a.downloads || 0));
    const artists = {};
    for (const t of published) {
      const key = (t.handle || t.artist || "").toLowerCase();
      if (!artists[key]) artists[key] = { artist: t.artist, handle: t.handle, plays: 0, downloads: 0, tapes: 0 };
      artists[key].plays += t.plays || 0;
      artists[key].downloads += t.downloads || 0;
      artists[key].tapes += 1;
    }
    const artistList = Object.values(artists);
    const top = (arr, field, min) => arr.filter((a) => (a[field] || 0) > (min || 0)).slice(0, 10).map((a) => ({ artist: a.artist, handle: a.handle, count: a[field] }));
    res.json({
      ok: true, year,
      totals: { plays: totalPlays, downloads: totalDownloads, publishedTapes: published.length },
      topTapesByPlays: byPlays.filter((t) => (t.plays || 0) > 0).slice(0, 10).map((t) => ({ title: t.title, artist: t.artist, handle: t.handle, count: t.plays })),
      topTapesByDownloads: byDownloads.filter((t) => (t.downloads || 0) > 0).slice(0, 10).map((t) => ({ title: t.title, artist: t.artist, handle: t.handle, count: t.downloads })),
      topArtistsByPlays: top(artistList.slice().sort((a, b) => b.plays - a.plays), "plays"),
      topArtistsByDownloads: top(artistList.slice().sort((a, b) => b.downloads - a.downloads), "downloads"),
      mostMixtapes: artistList.slice().sort((a, b) => b.tapes - a.tapes).filter((a) => a.tapes > 0).slice(0, 10).map((a) => ({ artist: a.artist, handle: a.handle, count: a.tapes })),
    });
  });

  // ---- public artist profile ----------------------------------------------
  app.get("/api/artists/:handle", (req, res) => {
    if (sweepPremieres()) persist().catch(() => {});
    const handle = normHandle(req.params.handle);
    const user = store.users[handle];
    if (!user) return res.status(404).json({ ok: false, error: "No profile for " + handle + " yet." });
    const live = store.tapes.filter((t) => t.handle === handle && isLive(t)).map((t) => publicTape(t, req));
    const viewer = authUser(req);
    res.json({
      ok: true,
      profile: publicUser(user, apiBase(req)),
      isFollowing: !!(viewer && followersOf(user).indexOf(viewer.handle) >= 0),
      tapes: live,
      totals: { plays: live.reduce((s, t) => s + t.plays, 0), downloads: live.reduce((s, t) => s + t.downloads, 0), publishedTapes: live.length },
    });
  });

  app.get("/api/genres", (req, res) => res.json({ ok: true, genres: GENRES }));

  // 404 + error handler (JSON, never an HTML stack trace).
  app.use((req, res) => res.status(404).json({ ok: false, error: "No such endpoint: " + req.method + " " + req.path }));
  app.use((err, req, res, _next) => {
    console.error("error:", err && err.message);
    res.status(500).json({ ok: false, error: "Server error — try again." });
  });

  return { app, store };
}

if (require.main === module) {
  const { app } = createApp();
  app.listen(PORT, () => {
    console.log("getraw-backend listening on :" + PORT + " (data: " + DATA_DIR + ", uploads: " + UPLOADS_DIR + ")");
  });
}

module.exports = { createApp };
