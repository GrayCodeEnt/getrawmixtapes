# Deploy Get Raw backend to the Hetzner server

**Status: BUILT AND TESTED LOCALLY — NOT DEPLOYED.** Nothing here has
touched the Hetzner server, DNS, GitHub, or the Play Store yet.

## What you need from Kris at deploy time

1. **Hetzner Cloud web console access** (Hoopty-Server,
   178.156.213.139) as root — direct SSH from the assistant's VM is
   blocked, so deploy happens in the console, exactly like Hoopty.
   Hetzner sign-in needs his login + the one-time code it sends him.
2. **GoDaddy DNS** for `getrawmixtapes.com` (or the DNS record added
   alongside step 1).
3. Nothing to pay. No new accounts. No Stripe keys (Get Raw takes no
   money through the site — Cash App donations go straight to artists).

## 0. Do-not-touch checklist (read first)

- **Do NOT touch `/opt/hoopty`, the `hoopty` systemd unit, or
  `api.hoopty.rent`.** Hoopty stays exactly as it is.
- Get Raw lives in its **own** directory `/opt/getraw`, its **own**
  systemd unit `getraw`, its **own** port **3001** (Hoopty is 3000),
  its **own** data (`/opt/getraw/data`) and uploads
  (`/opt/getraw/uploads`), and its **own** address
  `https://api.getrawmixtapes.com`.
- If any step below shows Hoopty files or the `hoopty` service, stop
  and re-check the path before running anything.

## 1. DNS — GoDaddy (getrawmixtapes.com)

Add one record (same pattern as `api.hoopty.rent`):

| Type | Name | Value | TTL |
|---|---|---|---|
| A | `api` | `178.156.213.139` | 600 |

Wait for it to resolve before step 5:
`dig +short api.getrawmixtapes.com` → `178.156.213.139`.

## 2. Copy the backend to the server (Hetzner web console, as root)

The backend folder is `~/workspace/get-raw-app/backend/` on this VM.
Upload it the same way Hoopty was uploaded (tarball via the console —
do NOT paste code by hand). On the server:

```sh
# Confirm you are NOT in /opt/hoopty:
pwd; ls /opt/ | grep -E 'hoopty|getraw'
mkdir -p /opt/getraw
# Unpack the uploaded getraw-backend.tar.gz into /opt/getraw/
# (server.js, lib/, package.json, package-lock.json, getraw.service,
#  .env.example, README.md, DEPLOY.md)
cd /opt/getraw
node --version          # expect Node 18+ (Hoopty already runs Node here)
npm install --omit=dev  # express + multer only; no native modules
node --check server.js && echo "syntax OK"
ls data uploads 2>/dev/null || echo "data/ + uploads/ are created on first start"
```

`node_modules/` may be uploaded with the tarball or installed on the
server — either works; installing on the server is the clean route.

## 3. Secrets — `/opt/getraw/.env`

```sh
cp /opt/getraw/.env.example /opt/getraw/.env
# Edit .env and set ADMIN_TOKEN to a long random string:
openssl rand -hex 32
# Paste that value as ADMIN_TOKEN=... in /opt/getraw/.env
# (Featured-slot endpoint only. No other secrets exist — no Stripe,
#  no database password.)
chmod 600 /opt/getraw/.env
```

## 4. systemd — install the `getraw` unit

```sh
cp /opt/getraw/getraw.service /etc/systemd/system/getraw.service
systemctl daemon-reload
systemctl enable --now getraw
systemctl status getraw --no-pager   # expect: active (running)
journalctl -u getraw --no-pager | tail -5
curl -s http://127.0.0.1:3001/api/health
# expect: {"ok":true,"service":"getraw-backend","tapes":0,"users":0,...}
```

If it fails, read the log (`journalctl -u getraw`) and report the
exact error — do not restart Hoopty, do not edit `/opt/hoopty`.

## 5. Reverse proxy + HTTPS for `api.getrawmixtapes.com`

The server already terminates TLS for `api.hoopty.rent` somehow
(nginx or Caddy). **Mirror that setup — do not invent a new one:**

```sh
systemctl status nginx caddy --no-pager 2>/dev/null | head -20
# Find Hoopty's vhost and copy its pattern:
#   nginx: grep -rl hoopty /etc/nginx/sites-enabled/ /etc/nginx/conf.d/
#   caddy: grep -n hoopty /etc/caddy/Caddyfile
```

Add a vhost for `api.getrawmixtapes.com` proxying to
`http://127.0.0.1:3001` (same proxy headers as Hoopty's vhost —
notably `X-Forwarded-Proto`, which the backend trusts for building
`https://` media URLs). Then issue its certificate the same way
Hoopty's was issued (certbot for nginx, automatic for Caddy) and
reload the proxy. Verify:

```sh
curl -s https://api.getrawmixtapes.com/api/health
# expect: {"ok":true,"service":"getraw-backend","tapes":0,"users":0,...}
```

## 6. Push the rewired site (parent / GitHub)

The site frontend now calls the backend. Push
`~/workspace/get-raw-app/site/index.html` to the
**GrayCodeEnt/getrawmixtapes** repo as `index.html` (main branch).
GitHub Pages rebuilds in under a minute. Do **not** overwrite
`privacy/index.html` (the privacy page stays as it is).

Verify live:

```sh
curl -s https://getrawmixtapes.com/ | grep -c "api.getrawmixtapes.com"
# expect: 1 (the API base in the page script)
```

Then open https://getrawmixtapes.com in a browser: the feed loads
(empty at first — no tapes yet), no offline banner, Sign In / Create
Profile work.

## 7. Smoke test (two devices, or two browsers)

1. **Device A:** create a fan profile, sign in. Upload a tape as a
   new artist (new @handle + password) — it lands as a private draft
   in My Tapes. Publish Now.
2. **Device B (signed out, or a different phone):** open
   https://getrawmixtapes.com/tapes — the tape is in the feed.
   Play a track (plays: 1), download a track (downloads: 1).
3. **Device A:** reload — plays/downloads show 1 each. Rankings and
   Year-End stats show the tape.
4. **Device B:** sign in as the fan from step 1 — Saved downloads
   shows the tape. That is login-anywhere working.

## 8. Android app (separate step, after the site is live)

The app (v1.0.1, in Play internal testing) bundles the **old** site
as its offline copy (`app/src/main/assets/offline.html`). Rebuild it
as **v1.0.2** (versionCode 3) with the new `site/index.html` as the
offline copy, then upload the new `.aab` to the same internal testing
track. The live site loads first anyway, so the app picks up the
backend as soon as the site is pushed — the rebuild only updates the
offline fallback.

## Rollback

- Backend: `systemctl stop getraw` (and optionally remove the
  `api.getrawmixtapes.com` vhost). The static site keeps working in
  its old form only if `index.html` is reverted in the repo — the
  rewired `index.html` shows its offline banner and cached feed when
  the backend is down, but logins/uploads need the backend.
- Data lives in `/opt/getraw/data/*.json` — back it up before any
  manual edit (`cp -r /opt/getraw/data /opt/getraw/data.bak.<date>`).
  Never edit the JSON files while the service is running.
- Hoopty is unaffected by any of this; if Hoopty breaks during this
  deploy, stop — the deploy touched the wrong directory.

## Limits to know (by design, for now)

- Data store is JSON files (same as Hoopty), not Postgres/SQLite.
  Fine for launch; if tapes/users grow into the thousands, move to
  SQLite/Postgres before it becomes a problem.
- Uploads live on the server disk under `/opt/getraw/uploads/`.
  Back them up with the data dir. No CDN yet.
- No admin dashboard: Featured is set via
  `POST /api/admin/tapes/:id/featured` with `X-Admin-Token`.
- Rate limits are per-IP in-memory (auth 20/min, plays/downloads
  60/min, uploads 10/min). They reset on restart — good enough for
  launch, not a substitute for a WAF.
