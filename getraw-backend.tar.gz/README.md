# Get Raw Mixtapes — shared backend

Artists upload once, everyone can listen. Users log in with their
`@handle` + password on any phone or computer and see their own profile,
tapes and drafts. This replaces the old per-browser storage: the Nov 19
site kept tapes and profiles in memory (and only year stats in
localStorage), so a tape uploaded on one phone never appeared anywhere
else — and even vanished on reload.

## What it is

- **Node + Express**, no paid services, no third-party accounts.
- **Auth:** `@handle` + password, scrypt-hashed (`lib/auth.js`), token
  sessions stored server-side (`data/sessions.json`, 30 days). A token
  works from any device.
- **Tapes:** draft → Publish Now / Schedule a Premiere → live feed.
  Search + genre filter, Featured, Artist of the Week, Rankings
  (Global / Local / Most Plays / Most Downloads / genre), Year-End
  stats (five boards). Plays and downloads are counted site-wide and
  kept **separate** everywhere, never mixed.
- **Files:** cover art + audio tracks stored on disk
  (`uploads/<tapeId>/`), streamed with HTTP Range support (seekable
  audio) and downloadable as attachments.
- **Data:** JSON files in `data/` (`users.json`, `tapes.json`,
  `sessions.json`) — atomic writes, same durable pattern as Hoopty.
  No password is ever stored or returned in plain text.

## Separation from Hoopty (Kris, Nov 19, 2026)

| | Hoopty | Get Raw |
|---|---|---|
| Directory | `/opt/hoopty` | `/opt/getraw` |
| systemd unit | `hoopty` | `getraw` |
| Port | 3000 | **3001** |
| Address | `https://api.hoopty.rent` | `https://api.getrawmixtapes.com` |
| Data | `/opt/hoopty/data` | `/opt/getraw/data` |

Nothing in this backend reads or writes anything under `/opt/hoopty`.

## Run locally

```sh
npm install
npm start          # listens on PORT (default 3001)
npm test           # API tests (10 tests, ephemeral port + temp data)
```

## API (all under `/api`, JSON unless noted)

| Method | Endpoint | Auth | What it does |
|---|---|---|---|
| GET | `/api/health` | — | `{ok, service, tapes, users}` |
| POST | `/api/auth/register` | — | Fan profile: `{name, handle, password, city}` → token |
| POST | `/api/auth/login` | — | `{handle, password}` → token + profile |
| POST | `/api/auth/logout` | token | Revokes the token |
| GET | `/api/auth/me` | token | Own profile + uploads + saved downloads |
| PATCH | `/api/auth/me` | token | `{name, city, cashtag}` |
| POST | `/api/tapes` | —* | Multipart upload (cover + tracks). Creates the artist profile on first upload; later uploads under the same handle need its password or a token for it. Always starts as a **draft**. |
| GET | `/api/tapes?search=&genre=` | — | Live tapes, newest first |
| GET | `/api/tapes?mine=1` | token | My tapes, incl. drafts |
| GET | `/api/tapes/:id` | — | One tape (live, or own draft) |
| POST | `/api/tapes/:id/publish` | owner | Draft → live now |
| POST | `/api/tapes/:id/schedule` | owner | `{releaseAt}` — premiere countdown |
| POST | `/api/tapes/:id/draft` | owner | Back to private draft |
| POST | `/api/tapes/:id/play` | — | +1 play (site-wide) |
| POST | `/api/tapes/:id/download` | — | +1 download, saves to my downloads if signed in |
| GET | `/api/media/:id/cover` | — | Cover art |
| GET | `/api/media/:id/track/:idx` | — | Audio stream (Range). `?download=1` = attachment |
| GET | `/api/featured` | — | Featured tapes + Artist of the Week + Coming Soon |
| GET | `/api/rankings?mode=&city=&genre=` | — | `global\|local\|plays\|downloads\|genre` |
| GET | `/api/stats/year/:year` | — | Five Year-End boards + totals |
| GET | `/api/artists/:handle` | — | Public profile + live tapes + totals |
| POST | `/api/admin/tapes/:id/featured` | `X-Admin-Token` | Set/unset Featured (paid $25 slot) |

\* Upload auth: a valid token for that handle, **or** the handle's
password in the form. A new handle is created with the given password.

Upload limits: 20 tracks max, 150 MB per track (MP3/M4A/WAV/FLAC/OGG/
AAC), cover 10 MB (JPG/PNG/WebP/GIF).

## Files in this folder

- `server.js` — the whole backend (Express app; `createApp()` is
  exported so tests can run it on an ephemeral port).
- `lib/store.js` — atomic JSON file store. `lib/auth.js` — scrypt
  passwords + token sessions.
- `getraw.service` — systemd unit for the Hetzner server.
- `.env.example` — config template (copy to `/opt/getraw/.env`).
- `DEPLOY.md` — exact deploy steps for the Hetzner web console.
- `test/api.test.js` — 10 API tests (`npm test`).

## Deploy

See [DEPLOY.md](DEPLOY.md). Summary: DNS `api.getrawmixtapes.com` →
178.156.213.139, copy this folder to `/opt/getraw` on the Hetzner
server (Hetzner Cloud web console, as root — direct SSH is blocked),
`npm install`, set `ADMIN_TOKEN` in `/opt/getraw/.env`, install the
systemd unit, add the reverse-proxy vhost + HTTPS for
`api.getrawmixtapes.com` (mirror how `api.hoopty.rent` is proxied),
then push the rewired site (`../site/index.html`) to the
GrayCodeEnt/getrawmixtapes repo and rebuild the Android app (v1.0.2)
so its bundled copy matches.
